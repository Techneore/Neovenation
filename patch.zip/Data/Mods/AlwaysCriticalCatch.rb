module PokeBattle_BattleCommon

def pbThrowPokeBall(idxPokemon,ball,rareness=nil,showplayer=false)
    itemname=getItemName(ball)
    battler=nil
    if pbIsOpposing?(idxPokemon)
      battler=self.battlers[idxPokemon]
    else
      battler=self.battlers[idxPokemon].pbOppositeOpposing
    end
    if battler.isFainted?
      battler=battler.pbPartner
    end
    oldform=battler.form
    battler.form=battler.pokemon.getForm(battler.pokemon)
    pbDisplayBrief(_INTL("{1} threw a {2}!",self.pbPlayer.name,itemname))
    if battler.isFainted?
      pbDisplay(_INTL("But there was no target..."))
      pbBallFetch(ball)
      return
    end
    if @opponent && (!pbIsSnagBall?(ball) || !battler.isShadow?)
      @scene.pbThrowAndDeflect(ball,1)
      if !($game_switches[:No_Catching] || battler.isbossmon || battler.issossmon)
        pbDisplay(_INTL("The Trainer blocked the Ball!\nDon't be a thief!"))
      else
        pbDisplay(_INTL("The Pokémon knocked the ball away!"))
      end
    else
      if $game_switches[:No_Catching] || battler.issossmon || (battler.isbossmon && (!battler.capturable || battler.shieldCount > 0)) 
        pbDisplay(_INTL("The Pokémon knocked the ball away!"))
        pbBallFetch(ball)
        return
      end
      pokemon=battler.pokemon
      species=pokemon.species
      shakes=4; critical=true; critsuccess=true ###### MOD ######
      @scene.pbThrow(ball,(critical) ? 1 : shakes,critical,critsuccess,battler.index,showplayer)
      # shadow catch should not be segmented like this
      @scene.pbWildBattleSuccess
      snag = pbIsSnagBall?(ball)
      pbDisplayPaused(_INTL("Gotcha! {1} was caught!",pokemon.name))
      @scene.pbThrowSuccess
      if snag && @opponent
        8.times do
          @scene.sprites["battlebox#{battler.index}"].opacity-=32
          @scene.pbGraphicsUpdate
        end
        pbRemoveFromParty(battler.index,battler.pokemonIndex)
        battler.pbReset
        battler.participants=[]
      else
        @decision=4
      end
      if snag
        pokemon.ot=self.pbPlayer.name
        pokemon.trainerID=self.pbPlayer.id
        $Trainer.pokedex.setOwned(pokemon)
      end
      BallHandlers.onCatch(ball,self,pokemon)
      pokemon.ballused=ball
      pokemon.pbRecordFirstMoves
      if !$Trainer.pokedex.dexList[species][:owned?] 
        $Trainer.pokedex.setOwned(pokemon)
        if $Trainer.pokedex.canViewDex && !snag
          pbDisplayPaused(_INTL("{1}'s data was added to the Pokédex.",pokemon.name))
          @scene.pbShowPokedex(species) 
        end
      end
      @scene.pbHideCaptureBall
      pbGainEXP
      pokemon.form=pokemon.getForm(pokemon)
      if snag && @opponent
        pokemon.pbUpdateShadowMoves rescue nil
        @snaggedpokemon.push(pokemon)
        @scene.partyBetweenKO1
      else
        pbStorePokemon(pokemon)
      end
    end
  end
end  