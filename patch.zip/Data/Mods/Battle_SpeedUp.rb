################################################################################
# Main battle class.
################################################################################
class PokeBattle_Battle
###### MOD ######
  attr_accessor(:spedup)
###### MOD ######

################################################################################
# Initialise battle class.
################################################################################
  #### YUMIL - 4.5 - NPC REACTION MOD - START  
  def initialize(scene,p1,p2,player,opponent,recorded=false)
    #### YUMIL - 4.5 - NPC REACTION MOD - START 
###### MOD ######
    if Graphics.frame_rate==40
      @spedup = false
    else
      @spedup = true
    end
    Graphics.frame_rate=200
###### MOD ######
    @battle          = self
    @scene           = scene
    @decision        = 0
    @internalbattle  = true
    @doublebattle    = false
    @cantescape      = false
    @shiftStyle      = true
    @battlescene     = true
    #### YUMIL - 5 - NPC REACTION MOD - START
    @recorded        = recorded
    #### YUMIL - 5 - NPC REACTION MOD - END 
    if opponent && player.is_a?(Array) && player.length==0
      player = player[0]
    end
    if opponent && opponent.is_a?(Array) && opponent.length==0
      opponent = opponent[0]
    end
    @player          = player                # PokeBattle_Trainer object
    @opponent        = opponent              # PokeBattle_Trainer object
    @party1          = p1
    @party2          = p2
    @partyorder     = (0...6).to_a
    @fullparty1      = false
    @fullparty2      = false
    @battlers        = []
    @items           = nil
    @partneritems    = nil
    @sides           = [Battle_Side.new,   # Player's side
                        Battle_Side.new]   # Foe's side
    @state           = Battle_Global.new    # Whole field (gravity/rooms)
    @field           = PokeBattle_Field.new
    @environment     = :None   # e.g. Tall grass, cave, still water
    @weather         = 0
    @weatherduration = 0
    @weatherbackup   = 0      #### DemICE - persistentweather
    @weatherbackupanim= nil  #### DemICE  - persistentweather
    @storm9          = false
    @switching       = false
    @choices         = [ [0,0,nil,-1],[0,0,nil,-1],[0,0,nil,-1],[0,0,nil,-1] ]
    @successStates   = []
    @lastMoveUsed    = -1
    @lastMoveUser    = -1
    @synchronize     = [-1,-1,0]
    @megaEvolution   = []
    @ultraBurst      = []
    @zMove           = []
    if @player.is_a?(Array)
      @megaEvolution[0]=[-1]*@player.length
      @ultraBurst[0]   =[-1]*@player.length
      @zMove[0]        =[-1]*@player.length
    else
      @megaEvolution[0]=[-1]
      @ultraBurst[0]   =[-1]
      @zMove[0]        =[-1] 
    end
    if @opponent.is_a?(Array)
      @megaEvolution[1]=[-1]*@opponent.length
      @ultraBurst[1]   =[-1]*@opponent.length
      @zMove[1]        =[-1]*@opponent.length
    else
      @megaEvolution[1]=[-1]
      @ultraBurst[1]   =[-1]
      @zMove[1]        =[-1]
    end
    @amuletcoin      = false
    @switchedOut     = []
    @extramoney      = 0
    @ace_message     = false
    @ace_message_handled = false
    @endspeech       = ""
    @endspeech2      = ""
    @endspeechwin    = ""
    @endspeechwin2   = ""
    @rules           = {}
    @turncount       = 0
    @peer            = PokeBattle_BattlePeer.create()
    @trickroom       = 0
    @priority        = []
    @usepriority     = false
    @snaggedpokemon  = []
    @runCommand      = 0
    @disableExpGain  = false
    @commandphase    = false
    @eruption        = false # Volcanictop Eruption check
    @sosbattle       = 2
    @struggle = PokeBattle_Move.pbFromPBMove(self,PBMove.new(:STRUGGLE),nil)
    @struggle.pp     = -1
    for i in 0...4
      battlers[i] = PokeBattle_Battler.new(self,i)
    end
    if !isOnline?
      for i in @party1
        next if !i
        next if i.nil?
        i.obedient = i.level <= LEVELCAPS[pbPlayer.numbadges]
      end
    end
    for i in @party1
      next if !i
      i.itemRecycle = nil
      i.itemInitial = i.item
      i.itemReallyInitialHonestlyIMeanItThisTime = i.item
      i.belch       = false
      i.piece       = nil
    end
    for i in @party2
      next if !i
      i.itemRecycle = nil
      i.itemInitial = i.item
      i.belch       = false
      i.piece       = nil
    end
  #### YUMIL - 6 - NPC REACTION MOD - START  
    if @recorded || @battle.FE == :CROWD
      createNewBattleRecord
    end
  #### YUMIL - 6 - NPC REACTION MOD - END   
  end

################################################################################
# End of battle.
################################################################################
  def pbEndOfBattle(canlose=false)
###### MOD ######
    if @spedup
      Graphics.frame_rate=200
      $speed_up = true
    else
      Graphics.frame_rate=40
      $speed_up = false
    end
###### MOD ######
    $position = Audio.bgm_pos
    case @decision
    ##### WIN #####
      when 1
        $game_variables[:Egg_Battle_Count]+=1 if Desolation && $game_variables[:Egg_Battle_Count]>0 && $game_variables[:Egg_Battle_Count]<1000 
        if @opponent
          @scene.pbTrainerBattleSuccess
          if @opponent.is_a?(Array)
            pbDisplayPaused(_INTL("{1} defeated {2} and {3}!",self.pbPlayer.name,@opponent[0].fullname,@opponent[1].fullname))
          else
            pbDisplayPaused(_INTL("{1} defeated\r\n{2}!",self.pbPlayer.name,@opponent.fullname))
          end
          @scene.pbShowOpponent(0)
          pbDisplayPaused(@endspeech.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
          if @opponent.is_a?(Array)
            @scene.pbHideOpponent
            @scene.pbShowOpponent(1)
            pbDisplayPaused(@endspeech2.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
          end
          # Calculate money gained for winning
          if @internalbattle
            tmoney=0
            if @opponent.is_a?(Array)   # Double battles
              maxlevel1=0; maxlevel2=0; limit=pbSecondPartyBegin(1)
              for i in 0...limit
                if @party2[i]
                  maxlevel1=@party2[i].level if maxlevel1<@party2[i].level
                end
                if @party2[i+limit]
                  maxlevel2=@party2[i+limit].level if maxlevel1<@party2[i+limit].level
                end
              end
              maxlevel1=[100,maxlevel1].min
              maxlevel2=[100,maxlevel2].min
              tmoney+=maxlevel1*@opponent[0].moneyEarned
              tmoney+=maxlevel2*@opponent[1].moneyEarned
            else
              maxlevel=0
              for i in @party2
                next if !i
                maxlevel=i.level if maxlevel<i.level
              end
              tmoney+=maxlevel*@opponent.moneyEarned
            end
            # If Amulet Coin/Luck Incense's effect applies, double money earned
            badgemultiplier = (1+(self.pbPlayer.numbadges/3)).floor
            badgemultiplier = (1+(self.pbPlayer.numbadges/2)).floor if Desolation || Rejuv
            tmoney*=badgemultiplier
            tmoney*=2 if @amuletcoin
            tmoney*=2 if  $game_switches[:Moneybags]
            if $game_switches[:Grinding_Trainer_Money_Cut] || $game_switches[:Penniless_Mode] #grinding trainers
              tmoney*=0.2
              tmoney= tmoney.floor
            end
            tmoney *= 2 if $game_variables[:LuckMoney] != 0
            tmoney = 0 if $game_variables[:LuckMoney] > 10 || $game_variables[:LuckMoney] < -10
            oldmoney=self.pbPlayer.money
            if $game_variables[:LuckMoney] < 0
              self.pbPlayer.money-=tmoney
              moneylost=oldmoney-self.pbPlayer.money
              if moneylost>0
                pbDisplayPaused(_INTL("{1} paid ${2}\r\nfor winning!",self.pbPlayer.name,tmoney))
              end
            else
              self.pbPlayer.money+=tmoney
              moneygained=self.pbPlayer.money-oldmoney
              if moneygained>0
                pbDisplayPaused(_INTL("{1} got ${2}\r\nfor winning!",self.pbPlayer.name,tmoney))
              end
            end
          end
        elsif Rejuv && @party2[0].isbossmon
          bossname = $cache.bosses[@party2[0].bossId].name
          @scene.pbBossBattleSuccess(bossname)
          pbDisplayPaused(_INTL("{1} defeated\r\n{2}!",self.pbPlayer.name,bossname))
        end
        if @internalbattle && @extramoney>0
          @extramoney*=2 if @amuletcoin
          oldmoney=self.pbPlayer.money
          self.pbPlayer.money+=@extramoney
          moneygained=self.pbPlayer.money-oldmoney
          if moneygained>0
            pbDisplayPaused(_INTL("{1} picked up ${2}!",self.pbPlayer.name,@extramoney))
          end
        end
        for pkmn in @snaggedpokemon
          pbStorePokemon(pkmn)
         # self.pbPlayer.shadowcaught=[] if !self.pbPlayer.shadowcaught
         # self.pbPlayer.shadowcaught[pkmn.species]=true
        end
        @snaggedpokemon.clear
        if Rejuv
          returnStolenPokemon(true,nil)
        end
        # Update Healingitem 
        if $PokemonGlobal.partner && @player.is_a?(Array)
          $PokemonGlobal.partner[4] = @partneritems if $PokemonGlobal.partner[4] = @partneritems
        end
    ##### LOSE, DRAW #####
      when 2, 5
        if @internalbattle
          pbDisplayPaused(_INTL("{1} is out of usable Pokémon!",self.pbPlayer.name))
          moneylost=pbMaxLevelFromIndex(0)
          multiplier=[8,16,24,36,48,64,80,100,120,140,160,180,190,200,210,220,230,240,250,250] #Badge no. multiplier for money lost
          moneylost*=multiplier[[multiplier.length-1,self.pbPlayer.numbadges].min]
          moneylost=self.pbPlayer.money if moneylost>self.pbPlayer.money
          moneylost=0 if $game_switches[:No_Money_Loss]
          self.pbPlayer.money-=moneylost
          if @opponent
            if @opponent.is_a?(Array)
              pbDisplayPaused(_INTL("{1} lost against {2} and {3}!",self.pbPlayer.name,@opponent[0].fullname,@opponent[1].fullname))
            else
              pbDisplayPaused(_INTL("{1} lost against\r\n{2}!",self.pbPlayer.name,@opponent.fullname))
            end
            if moneylost>0
              pbDisplayPaused(_INTL("{1} paid ${2}\r\nas the prize money...",self.pbPlayer.name,moneylost))
              pbDisplayPaused(_INTL("...")) if !canlose
            end
          else
            if moneylost>0
              pbDisplayPaused(_INTL("{1} panicked and lost\r\n${2}...",self.pbPlayer.name,moneylost))
              pbDisplayPaused(_INTL("...")) if !canlose
            end
          end
          pbDisplayPaused(_INTL("{1} blacked out!",self.pbPlayer.name)) if !canlose
        elsif @decision==2
          @scene.pbShowOpponent(0)
          pbDisplayPaused(@endspeechwin.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
          if @opponent.is_a?(Array)
            @scene.pbHideOpponent
            @scene.pbShowOpponent(1)
            pbDisplayPaused(@endspeechwin2.gsub(/\\[Pp][Nn]/,self.pbPlayer.name))
          end
        elsif @decision==5
          PBDebug.log("***[Draw game]") if $INTERNAL
        end
        if Rejuv
          returnStolenPokemon(true,nil)
        end
        $game_screen.weather(0,0,0)
    end
    # Change bad poison to normal poison
    for i in $Trainer.party
      next if i.nil?
      if i.statusCount > 0 && i.status == :POISON
        i.statusCount = 0
      end
    end

    # Pass on Pokérus within the party
    infected=[]
    for i in 0...$Trainer.party.length
      if $Trainer.party[i].pokerusStage==1
        infected.push(i)
      end
    end
    if infected.length>=1
      for i in infected
        strain=$Trainer.party[i].pokerus/16
        if i>0 && $Trainer.party[i-1].pokerusStage==0
          $Trainer.party[i-1].givePokerus(strain) if pbRandom(3)==0
        end
        if i<$Trainer.party.length-1 && $Trainer.party[i+1].pokerusStage==0
          $Trainer.party[i+1].givePokerus(strain) if pbRandom(3)==0
        end
      end
    end
    if $game_variables[:LuckMoney]!=0 && @opponent
      $game_variables[:LuckMoney] -= 1 if $game_variables[:LuckMoney] > 0
      $game_variables[:LuckMoney] += 1 if $game_variables[:LuckMoney] < 0
      pbDisplayPaused(_INTL("Mr Luck's money contract lost its effect!")) if $game_variables[:LuckMoney]==0
    end
    if $game_variables[:LuckShinies]!=0 && !@opponent && !@party2[0].isbossmon
      $game_variables[:LuckShinies] -= 1 if $game_variables[:LuckShinies] > 0
      $game_variables[:LuckShinies] += 1 if $game_variables[:LuckShinies] < 0
      pbDisplayPaused(_INTL("Mr Luck's shiny contract lost its effect!")) if $game_variables[:LuckShinies]==0
    end
    if $game_variables[:LuckMoves]!=0 && !@opponent && !@party2[0].isbossmon
      $game_variables[:LuckMoves] -= 1 if $game_variables[:LuckMoves] > 0
      $game_variables[:LuckMoves] += 1 if $game_variables[:LuckMoves] < 0
      pbDisplayPaused(_INTL("Mr Luck's technique contract lost its effect!")) if $game_variables[:LuckMoves]==0
    end
    @scene.pbEndBattle(@decision)

    # Resetting all the temporary forms
    for i in @battlers
      i.pbResetForm
    end
    for i in @party1
      next if i.nil?
      i.makeUnmega if i.isMega?
      i.makeUnprimal if i.isPrimal?
      i.makeUnultra if i.isUltra?
      if i.species == :ZYGARDE && !i.originalForm.nil?
        hpbackup = i.hp
        i.form=i.originalForm
        i.originalForm = nil
        i.hp=[hpbackup,i.totalhp].min
      end
      i.form=0 if i.species == :MIMIKYU || i.species == :EISCUE
      if Rejuv
        i.form=1 if ((i.species == :PARAS || i.species == :PARASECT) && i.form == 2)
        i.prismPower = false
        i.rampCrestUsed = false
      end
    end
    for i in $Trainer.party
      i.setItem(i.itemInitial)
      i.setItem(i.itemReallyInitialHonestlyIMeanItThisTime) if Rejuv && $game_switches[:NotPlayerCharacter]
      i.itemInitial=i.itemRecycle=nil
      i.form=i.getForm(i)
    end
    #Set variables to field effect values
    $game_variables[:Field_Effect_End_Of_Battle] = @field.effect
    $game_variables[:Field_Counter_End_Of_Battle] = @field.counter
    $game_variables[:Weather_End_Of_Battle] = @weather

    return @decision
  end
end
