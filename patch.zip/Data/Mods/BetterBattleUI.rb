$betterBattleUI_typeIcons_bitmaps = nil # Force the reloading of disposed graphics on soft resetting
$betterBattleUI_difficultyIcons_bitmaps = nil

module BBUIConsts
  X_PAD = 50
  Y_PAD = 40
end

### Command Menu Throw Ball

class BetterBattleUI_PokeballThrowButtonDisplay
  def initialize(battle,viewport=nil)
    @battle = battle
    @display=BetterBattleUI_PokeballThrowButton.new(viewport)
  end

  def updateData(index)
    @display.updateData(index, @battle)
  end

  def throwBall(scene)
    ball = @display.pokeball
    if pbIsPokeBall?(ball) && ItemHandlers.hasBattleUseOnBattler(ball) && @display.canCatch(@battle)
      scene.betterBattleUI_autoselectitem = ball
      return true
    end
    return false
  end

  def changeBall(index)
    $PokemonBag.setChoice(3, ($PokemonBag.getChoice(3) + 1) % $PokemonBag.pockets[3].length)
    updateData(index)
  end

  def x; @display.x; end
  def x=(value)
    @display.x=value
  end

  def y; @display.y; end
  def y=(value)
    @display.y=value
  end

  def z; @display.z; end
  def z=(value)
    @display.z=value
  end

  def ox; @display.ox; end
  def ox=(value)
    @display.ox=value
  end

  def oy; @display.oy; end
  def oy=(value)
    @display.oy=value
  end

  def visible; @display.visible; end
  def visible=(value)
    @display.visible=value
  end

  def color; @display.color; end
  def color=(value)
    @display.color=value
  end

  def disposed?
    return @display.disposed?
  end

  def dispose
    return if disposed?
    @display.dispose
  end

  def refresh
    @display.refresh
  end

  def update
    @display.update
  end
end


class BetterBattleUI_PokeballThrowButton < BitmapSprite
  attr_reader :pokeball

  def initialize(viewport=nil)
    super(44,68,viewport)
    self.x=0
    self.y=118
    @buttonbitmap=AnimatedBitmap.new("Data/Mods/BetterBattleUI/ThrowBall")
    @pokeball = nil
    @pokeballbitmap=nil
    @cancatch = false
  end

  def dispose
    @buttonbitmap.dispose
    super
  end

  def updateData(index, battle)
    @index = index

    ball = $PokemonBag.pockets[3][$PokemonBag.getChoice(3)] || $PokemonBag.pockets[3][0]  # Pokeballs
    if !ball.nil? && pbIsPokeBall?(ball) && (ball != @pokeball || !@pokeballbitmap)
      @pokeball = ball
      @pokeballbitmap = AnimatedBitmap.new(sprintf("Graphics/Icons/" + @pokeball.to_s.downcase))
    end

    @cancatch = canCatch(battle)

    refresh
  end

  def refresh
    self.bitmap.clear
    if @pokeballbitmap && @cancatch
      self.bitmap.blt(0,0,@buttonbitmap.bitmap,Rect.new(0,0,44,68))
      self.bitmap.blt(-4,0,@pokeballbitmap.bitmap,Rect.new(0,0,48,48))
    end
  end

  def update
    refresh
  end

  def canCatch(battle)
    if battle.pbIsOpposing?(@index)
      target=battle.battlers[@index]
    else
      target=battle.battlers[@index].pbOppositeOpposing
    end
    if target.isFainted?
      target=target.pbPartner
    end
    return false if @pokeball == nil || $PokemonBag.pbQuantity(@pokeball) == 0
    return false if target.isFainted?
    return false if battle.opponent && (!pbIsSnagBall?(@pokeball) || !target.isShadow?)
    return false if $game_switches[:No_Catching] || target.issossmon || (target.isbossmon && (!target.capturable || target.shieldCount > 0))
    return true
  end
end

class PokeBattle_Scene

  alias :betterBattleUI_old_pbStartBattle :pbStartBattle

  def pbStartBattle(battle)
    betterBattleUI_old_pbStartBattle(battle)
    @sprites["bbui_ballwindow"]=BetterBattleUI_PokeballThrowButtonDisplay.new(@battle,@viewport)
    @sprites["bbui_ballwindow"].z=100
  end


  alias :betterBattleUI_old_pbEndBattle :pbEndBattle

  def pbEndBattle(*args, **kwargs)
    $betterBattleUI_typeIcons_bitmaps = nil
    return betterBattleUI_old_pbEndBattle(*args, **kwargs)
  end

  alias :betterBattleUI_old_pbShowWindow :pbShowWindow

  def pbShowWindow(windowtype)
    betterBattleUI_old_pbShowWindow(windowtype)
    @sprites["bbui_ballwindow"].visible=windowtype==COMMANDBOX if @sprites["bbui_ballwindow"]
  end

  attr_accessor :betterBattleUI_autoselectitem
  alias :betterBattleUI_old_pbItemMenu :pbItemMenu

  def pbItemMenu(i)
    if @betterBattleUI_autoselectitem
      ret = @betterBattleUI_autoselectitem
      @betterBattleUI_autoselectitem = nil
      return [ret, $PokemonBag.getChoice(3)]
    end
    return betterBattleUI_old_pbItemMenu(i)
  end

  def pbCommandMenuEx(index,texts,mode=0)      # Mode: 0 - regular battle
    pbShowWindow(COMMANDBOX)                   #       1 - Shadow Pokémon battle
    cw=@sprites["commandwindow"]               #       2 - Safari Zone
    cw.setTexts(texts)                         #       3 - Bug Catching Contest
    cw.index=0 if @lastcmd[index]==2
    cw.mode=mode
    ### MODDED/
    bw=@sprites["bbui_ballwindow"]
    bw.updateData(index) if bw
    ### /MODDED
    pbSelectBattler(index)
    pbRefresh
    update_menu=true
    loop do
      pbGraphicsUpdate
      Input.update
      pbFrameUpdate(cw,update_menu)
      ### MODDED/
      bw.updateData(index) if bw
      ### /MODDED
      update_menu=false
      # Update selected command
      if Input.trigger?(Input::CTRL)
        pbToggleStatsBoostsVisibility
        pbPlayCursorSE()
        update_menu=true
      elsif Input.trigger?(Input::LEFT) && (cw.index&1)==1
        pbPlayCursorSE()
        cw.index-=1
        update_menu=true
      elsif Input.trigger?(Input::RIGHT) &&  (cw.index&1)==0
        pbPlayCursorSE()
        cw.index+=1
        update_menu=true
      elsif Input.trigger?(Input::UP) &&  (cw.index&2)==2
        pbPlayCursorSE()
        cw.index-=2
        update_menu=true
      elsif Input.trigger?(Input::DOWN) &&  (cw.index&2)==0
        pbPlayCursorSE()
        cw.index+=2
        update_menu=true
      ### MODDED/
      elsif Input.trigger?(Input::B) && index==0 && cw.index != 3 # X Over Run
        pbPlayDecisionSE()
        cw.index=3
        update_menu=true
      elsif Input.trigger?(Input::L) # Throw Pokeball Directly
        if bw.throwBall(self)
          pbPlayDecisionSE()
          return 1
        end
      elsif Input.trigger?(Input::R) # Change Pokeball
        if $PokemonBag.pockets[3].length > 1
          pbPlayDecisionSE()
          bw.changeBall(index)
        end
      ### /MODDED
      elsif Input.trigger?(Input::Y)  #Show Battle Stats feature made by DemICE
        statstarget=pbStatInfo(index)
        return -1 if statstarget==-1
        if !pbInSafari?
          pbShowBattleStats(statstarget)
        end
      end
      if Input.trigger?(Input::C)   # Confirm choice
        pbPlayDecisionSE()
        ret=cw.index
        @lastcmd[index]=ret
        cw.index=0 if $Settings.remember_commands==0
        return ret
      elsif Input.trigger?(Input::B) && index==2 #&& @lastcmd[0]!=2 # Cancel #Commented out for cancelling switches in doubles
        pbPlayDecisionSE()
        return -1
      end
    end
  end

  ###
end

###

class PokemonDataBox < SpriteWrapper

  def initialize(battler,doublebattle,viewport=nil,battle)
    super(viewport)
    @explevel=0
    @battler=battler
    @battle = battle
    @selected=0
    @frame=0
    @showhp=false
    @showexp=false
    @appearing=false
    @animatingHP=false
    @animatingScale=0 # add this line
    @starthp=0
    @currenthp=0
    @endhp=0
    @expflash=0
    @doublebattle=doublebattle
    if (@battler.index&1)==0 # if player's Pokémon
      @spritebaseX=34
    else
      @spritebaseX=16
    end
    @spritebaseY=0
    if doublebattle
      case @battler.index
        when 0
          @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/battlePlayerBoxD")
          @spriteX=PBScene::PLAYERBOXD1_X
          @spriteY=PBScene::PLAYERBOXD1_Y
        when 1
          if @battler.issossmon
            @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/boss_bar_sos")
            @spriteX=PBScene::FOEBOXD1_X-12
            @spriteY=PBScene::FOEBOXD1_Y-23
          else
            @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/battleFoeBoxD")
            @spriteX=PBScene::FOEBOXD1_X
            @spriteY=PBScene::FOEBOXD1_Y
          end
        when 2
          @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/battlePlayerBoxD")
          @spriteX=PBScene::PLAYERBOXD2_X
          @spriteY=PBScene::PLAYERBOXD2_Y
        when 3
          if @battler.issossmon
            @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/boss_bar_sos")
            @spriteX=PBScene::FOEBOXD2_X+8
            @spriteY= PBScene::FOEBOXD2_Y+23
          else
            @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/battleFoeBoxD")
            @spriteX=PBScene::FOEBOXD2_X+4
            @spriteY=PBScene::FOEBOXD2_Y
          end
      end
    else
      case @battler.index
        when 0
          @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/battlePlayerBoxS")
          @spriteX=PBScene::PLAYERBOX_X
          @spriteY=PBScene::PLAYERBOX_Y
          @showhp=true
          @showexp=true
        when 1
          @databox=AnimatedBitmap.new("Graphics/Pictures/Battle/battleFoeBoxS")
          @spriteX=PBScene::FOEBOX_X+4
          @spriteY=PBScene::FOEBOX_Y
      end
    end
    ### MODDED/
    @spriteX -= BBUIConsts::X_PAD
    @spritebaseX += BBUIConsts::X_PAD
    @spriteY -= BBUIConsts::Y_PAD
    @spritebaseY += BBUIConsts::Y_PAD

    @contents=BitmapWrapper.new(@databox.width+(BBUIConsts::X_PAD*2),@databox.height+(BBUIConsts::Y_PAD*2))
    ### /MODDED
    self.bitmap=@contents
    self.visible=false
    self.z=50
    refreshExpLevel
    refresh
  end

  def refresh
    self.bitmap.clear
    return if !@battler.pokemon
    bIsFoe = ((@battler.index == 1) || (@battler.index == 3))
    filename = @battler.issossmon && (battler.index != 2) ? "Graphics/Pictures/Battle/" : "Graphics/Pictures/Battle/battle"
    if @doublebattle
      case @battler.index % 2
        when 0
          if @battler.issossmon
            filename += "PlayerBoxSOS"
          else
            filename += "PlayerBoxD"
          end
        when 1
          if @battler.issossmon
            filename += "boss_bar_sos"
          else
            filename += "FoeBoxD"
          end
      end
    else
      case @battler.index
        when 0
          filename += "PlayerBoxS"
        when 1
          filename += "FoeBoxS"
      end
    end
    filename += battlerStatus(@battler) if !@battler.issossmon || (@battler.issossmon && @battler.index==2)
    @databox=AnimatedBitmap.new(filename)

    ### MODDED/
    self.bitmap.blt(BBUIConsts::X_PAD,BBUIConsts::Y_PAD,@databox.bitmap,Rect.new(0,0,@databox.width,@databox.height))
    ### /MODDED
    if @doublebattle
      if !@battler.issossmon || (battler.issossmon && battler.index == 2)
        @hpbar = AnimatedBitmap.new("Graphics/Pictures/Battle/hpbardoubles")
      else
        @hpbar = AnimatedBitmap.new("Graphics/Pictures/Battle/hpbarsos")
      end
      hpbarconstant=PBScene::HPGAUGEHEIGHTD
    else
      @hpbar = AnimatedBitmap.new("Graphics/Pictures/Battle/hpbar")
      hpbarconstant=PBScene::HPGAUGEHEIGHTS
    end
    base=PBScene::BOXBASE
    shadow=PBScene::BOXSHADOW
    ### MODDED/ Add sbY
    sbY = @spritebaseY
    headerY = 18 + sbY
    sbX = @spritebaseX
    if bIsFoe
      headerY += 4
      sbX -= 12
    end
    if @doublebattle
      headerY -= 12
      sbX += 6

      if bIsFoe
        headerY -= 4
        sbX += 2
      end
    end

    # Pokemon Name
    pokename=@battler.name
    if @battler.issossmon && !(@battler.index == 2)
      pbSetSmallFont(self.bitmap)
      nameposition=sbX+4
    else
      pbSetSystemFont(self.bitmap)
      nameposition=sbX+8
    end

    textpos=[
       [pokename,nameposition,headerY,false,base,shadow]
    ]
    leveltxt = _INTL("Lv{1}",$game_switches[1306] && (@battler.index%2)==1 ? "???" : @battler.level)
    if !@battler.issossmon  || (@battler.issossmon && @battler.index == 2)
      genderX=self.bitmap.text_size(pokename).width
      genderX+=sbX+14
      if genderX > (165 + BBUIConsts::X_PAD) && !@doublebattle && (@battler.index&1)==1 #opposing pokemon
        genderX = sbX-16+206-self.bitmap.text_size(leveltxt).width
      end
      gendertarget = @battler.effects[:Illusion] ? @battler.effects[:Illusion] : @battler
      gendertarget = gendertarget.pokemon if gendertarget.is_a?(PokeBattle_Battler)
      if gendertarget.gender==0 # Male
        textpos.push([_INTL("♂"),genderX,headerY,false,Color.new(48,96,216),shadow])
      elsif gendertarget.gender==1 # Female
        textpos.push([_INTL("♀"),genderX,headerY,false,Color.new(248,88,40),shadow])
      end
    end
    pbDrawTextPositions(self.bitmap,textpos)
    pbSetSmallFont(self.bitmap)
    # Level
    hpShiftX = 202
    if bIsFoe
      hpShiftX -= 4
    end
    textpos=[[leveltxt,sbX+hpShiftX,headerY+8,true,base,shadow]]
    textpos=[] if @battler.issossmon
    # HP Numbers
    if @showhp
      hpstring=_ISPRINTF("{1: 2d}/{2: 2d}",self.hp,@battler.totalhp)
      textpos.push([hpstring,sbX+202,sbY+78,true,base,shadow])
    end
    pbDrawTextPositions(self.bitmap,textpos)
    # Shiny
    imagepos=[]
    if (@battler.pokemon.isShiny? && @battler.effects[:Illusion].nil?) || (!@battler.effects[:Illusion].nil? && @battler.effects[:Illusion].isShiny?)
      shinyX=202
      shinyX=-16 if (@battler.index&1)==0 # If player's Pokémon
      shinyY=24
      shinyY=12 if @doublebattle
      if (@battler.index&1)==1 && !@doublebattle
        shinyY+=4
      end
      imagepos.push(["Graphics/Pictures/shiny.png",sbX+shinyX,sbY+shinyY,0,0,-1,-2])
    end
    # Mega
    megaY=52
    megaY-=4 if (@battler.index&1)==0 # If player's Pokémon
    megaY=32 if @doublebattle
    megaX=215
    megaX=-27 if (@battler.index&1)==0 # If player's Pokémon
    if !@battler.issossmon || (@battler.issossmon && @battler.index == 2)
      if @battler.pokemon.isPulse?
        imagepos.push(["Graphics/Pictures/Battle/battlePulseEvoBox.png",sbX+megaX,sbY+megaY,0,0,-1,-1])
      elsif @battler.pokemon.isRift?
        imagepos.push(["Graphics/Pictures/Battle/battleRiftEvoBox.png",sbX+megaX,sbY+megaY,0,0,-1,-1])
      elsif @battler.pokemon.isPerfection?
        imagepos.push(["Graphics/Pictures/Battle/battlePerfectionEvoBox.png",sbX+megaX,sbY+megaY,0,0,-1,-1])
      elsif @battler.isMega?
        imagepos.push(["Graphics/Pictures/Battle/battleMegaEvoBox.png",sbX+megaX,sbY+megaY,0,0,-1,-1])
      elsif @battler.isUltra? # Maybe temporary until new icon
        imagepos.push(["Graphics/Pictures/Battle/battleMegaEvoBox.png",sbX+megaX,sbY+megaY,0,0,-1,-1])
      end
      # Crest
      illusion = !@battler.effects[:Illusion].nil?
      if @battler.hasCrest?(illusion) || (@battler.crested && !illusion)
        imagepos.push(["Graphics/Pictures/Battle/battleCrest.png",sbX+megaX,sbY+megaY,0,0,-1,-1])
      end
      # Owned
      if @battler.owned && (@battler.index&1)==1
        if @doublebattle
          imagepos.push(["Graphics/Pictures/Battle/battleBoxOwned.png",sbX-12,sbY+4,0,0,-1,-1]) if (@battler.index)==3
          imagepos.push(["Graphics/Pictures/Battle/battleBoxOwned.png",sbX-18,sbY+4,0,0,-1,-1]) if (@battler.index)==1
        else
          imagepos.push(["Graphics/Pictures/Battle/battleBoxOwned.png",sbX-12,sbY+20,0,0,-1,-1])
        end
      end
      ### MODDED/ crest display for sos
    else
      # Crest
      illusion = !@battler.effects[:Illusion].nil?
      if @battler.hasCrest?(illusion) || (@battler.crested && !illusion)
        imagepos.push(["Graphics/Pictures/Battle/battleCrest.png",sbX+100,sbY-4,0,0,-1,-1])
      end
      ### /MODDED
    end
    pbDrawImagePositions(self.bitmap,imagepos)
    hpGaugeSize=PBScene::HPGAUGESIZE
    hpgauge=@battler.totalhp==0 ? 0 : (self.hp*hpGaugeSize/@battler.totalhp)
    hpgauge=2 if hpgauge==0 && self.hp>0
    hpzone=0
    hpzone=1 if self.hp<=(@battler.totalhp/2.0).floor
    hpzone=2 if self.hp<=(@battler.totalhp/4.0).floor
    hpcolors=[
      PBScene::HPGREENDARK,
      PBScene::HPGREEN,
      PBScene::HPYELLOWDARK,
      PBScene::HPYELLOW,
      PBScene::HPREDDARK,
      PBScene::HPRED
    ]
    # fill with black (shows what the HP used to be)
    hpGaugeX=PBScene::HPGAUGE_X
    hpGaugeY=PBScene::HPGAUGE_Y
    if @battler.issossmon && (@battler.index&1)!=0 && !(@battler.index == 2)
      hpGaugeY=PBScene::HPGAUGE_Y-10
      hpGaugeX=PBScene::HPGAUGE_X-16
    end
    hpGaugeLowerY = 14
    hpThiccness = 16
    if bIsFoe
      hpGaugeX += 8
      hpGaugeY += 4
    end
    if @doublebattle
      hpGaugeY -= 12
      hpGaugeLowerY = 10
      hpThiccness = 12

      if bIsFoe
        hpGaugeY -= 4
      end
    end
    self.bitmap.blt(sbX+hpGaugeX,sbY+hpGaugeY,@hpbar.bitmap,Rect.new(0,(hpzone)*hpbarconstant,hpgauge,hpbarconstant))

    # self.bitmap.fill_rect(sbX+hpGaugeX,sbY+hpGaugeY,hpgauge,hpThiccness,hpcolors[hpzone*2+1])
    # self.bitmap.fill_rect(sbX+hpGaugeX,sbY+hpGaugeY,hpgauge,2,hpcolors[hpzone*2])
    # self.bitmap.fill_rect(sbX+hpGaugeX,sbY+hpGaugeY+hpGaugeLowerY,hpgauge,2,hpcolors[hpzone*2])
    # Status
    if !@battler.status.nil?
      imagepos=[]
      doubles = "D"
      if @doublebattle
        if bIsFoe
          if @battler.issossmon && !(@battler.index == 2)
            imagepos.push([sprintf("Graphics/Pictures/Battle/battleStatuses"+ doubles + "%s",@battler.status),@spritebaseX-6,@spritebaseY+26,0,0,64,28])
          else
            imagepos.push([sprintf("Graphics/Pictures/Battle/battleStatuses"+ doubles + "%s",@battler.status),@spritebaseX+8,@spritebaseY+36,0,0,64,28])
          end
        else
          imagepos.push([sprintf("Graphics/Pictures/Battle/battleStatuses"+ doubles + "%s",@battler.status),@spritebaseX+10,@spritebaseY+36,0,0,64,28])
        end
      elsif bIsFoe
        imagepos.push([sprintf("Graphics/Pictures/Battle/battleStatuses%s",@battler.status),@spritebaseX,@spritebaseY+54,0,0,64,28])
      else
        imagepos.push([sprintf("Graphics/Pictures/Battle/battleStatuses%s",@battler.status),@spritebaseX+4,@spritebaseY+50,0,0,64,28])
      end
      pbDrawImagePositions(self.bitmap,imagepos)
    end
    if @showexp
      # fill with EXP color
      expGaugeX=PBScene::EXPGAUGE_X
      expGaugeY=PBScene::EXPGAUGE_Y
      self.bitmap.fill_rect(sbX+expGaugeX,sbY+expGaugeY,self.exp,2,
         PBScene::EXPCOLORSHADOW)
      self.bitmap.fill_rect(sbX+expGaugeX,sbY+expGaugeY+2,self.exp,4,
         PBScene::EXPCOLORBASE)
    end
    ### /MODDED
    ### MODDED/
    betterBattleUI_typeIcons_apply if @battler.pokemon
    ### /MODDED
  end




  ### TypeIcons

  def betterBattleUI_typeIcons_apply
    battlerTypes = betterBattleUI_typeIcons_battlerType

    bIsFoe = ((@battler.index == 1) || (@battler.index == 3))
    issos = @battler.issossmon
    baseX=@spritebaseX + (bIsFoe ? 200 : -50)
    baseX -= 100 if issos
    baseY=(@spritebaseY || 0)
    baseY += 20 if !@doublebattle

    background1, background2 = betterBattleUI_typeIcons_backgroundBitmap(bIsFoe, issos)

    shiftX1 = bIsFoe ? 14 : 4
    shiftY1 = 0
    shiftX2 = bIsFoe ? 16 : 2
    shiftY2 = 28


    illusion = !@battler.effects[:Illusion].nil?
    crested = @battler.hasCrest?(illusion) || (@battler.crested && !illusion)
    shiny = (@battler.pokemon.isShiny? && @battler.effects[:Illusion].nil?) || (!@battler.effects[:Illusion].nil? && @battler.effects[:Illusion].isShiny?)
    if !@doublebattle
      shiftY2 += 8 if crested
      shiftY2 += 6
      shiftX2 += bIsFoe ? 2 : -2
    else
      shiftX2 += 8 if crested && bIsFoe
      shiftX2 += bIsFoe ? 4 : -4
      shiftY2 -= 2

      if !crested && !bIsFoe
        if shiny
          shiftX1 += 6
          shiftX2 += 6
        else
          shiftX1 += 16
          shiftX2 += 16
        end
      end
      if issos
        shiftY2 = shiftY1
        shiftX1 += 20
        shiftX2 += 34
      end
    end

    difficultyX = shiftX1 + 20
    difficultyY = shiftY1 + 14
    difficultyY -= 4 if @doublebattle

    self.bitmap.blt(baseX+shiftX1, baseY+shiftY1, background1, background1.rect)

    typepos=[]
    typepos.push([sprintf("Graphics/Icons/bosstype%s",battlerTypes[0]),baseX+4+shiftX1,baseY+4+shiftY1,0,0,64,28])
    if battlerTypes.length() > 1
      self.bitmap.blt(baseX+shiftX2, baseY+shiftY2, background2, background2.rect)
      typepos.push([sprintf("Graphics/Icons/bosstype%s",battlerTypes[1]),baseX+4+shiftX2,baseY+4+shiftY2,0,0,64,28])
    end

    ### MODDED/ Difficulty Icons
    if (@battler.index&1)==1
      if $game_switches[:Empty_IVs_And_EVs_Password]
        typepos.push(["Data/Mods/BetterBattleUI/DifficultyIcons.png",baseX+difficultyX,baseY+difficultyY,52,0,26,28])
      elsif $game_switches[:Flat_EV_Password]
        typepos.push(["Data/Mods/BetterBattleUI/DifficultyIcons.png",baseX+difficultyX,baseY+difficultyY,26,0,26,28])
      elsif $game_switches[:Only_Pulse_2]
        typepos.push(["Data/Mods/BetterBattleUI/DifficultyIcons.png",baseX+difficultyX,baseY+difficultyY, 0,0,26,28])
      end
    end

    pbDrawImagePositions(self.bitmap, typepos)
  end

  def betterBattleUI_typeIcons_backgroundBitmap(isFoe, issos)
    if !$betterBattleUI_typeIcons_bitmaps
      rawBmp=AnimatedBitmap.new("Data/Mods/BetterBattleUI/TypeDiamonds.png")
      retval=[]
      spriteWidth=26
      spriteHeight=28
      for y in 0..1
        for x in 0..2
          rect=Rect.new(x*spriteWidth,y*spriteHeight,spriteWidth,spriteHeight)
          bitmap=Bitmap.new(rect.width, rect.height)
          bitmap.blt(0, 0, rawBmp.bitmap, rect)
          retval.push(bitmap)
        end
      end

      $betterBattleUI_typeIcons_bitmaps=retval
    end

    idx = isFoe ? 1 : 0
    idx = 2 if issos

    return $betterBattleUI_typeIcons_bitmaps[idx], $betterBattleUI_typeIcons_bitmaps[idx+3]
  end

  def betterBattleUI_typeIcons_battlerType
    if @battler.effects[:Illusion]
      # Zorua
      type1=@battler.effects[:Illusion].type1
      type2=@battler.effects[:Illusion].type2
    else
      type1=@battler.type1
      type2=@battler.type2
    end
    typearray = [type1.to_s.upcase]
    typearray.push(type2.to_s.upcase) if type2 && (type2 != type1)
    return typearray
  end
end
