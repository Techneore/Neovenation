ITEMRESTOREREPLACE = true
class PokeBattle_Battler
  def pbDisposeItem(berry = true, symbiosis = true)
    if $Settings.itemRestoreReplace == 1 #Replace
      self.pokemon.itemRecycle = self.item
      # Remove from the bag to mimic the "replacement" of the used item by a new one
      if $PokemonBag.pbHasItem?(self.item)
        $PokemonBag.pbDeleteItem(self.item)
      else
        # remove the item for after the battle
        self.pokemon.itemInitial = nil if self.pokemon.itemInitial == self.item
      end
      self.item = nil
      pbBurp(self) if berry
      pbSymbiosis(self)
    elsif $Settings.itemRestoreReplace == 2 #Restore
      self.pokemon.itemRecycle = self.item
      self.item = nil
      # Commented to not remove the item after the battle
      # self.pokemon.itemInitial = nil if self.pokemon.itemInitial == self.item
      pbBurp(self) if berry
      pbSymbiosis(self)
    else #Off
      self.pokemon.itemRecycle=self.item
      self.pokemon.itemInitial=nil if self.pokemon.itemInitial==self.item
      self.item=nil
      pbBurp(self) if berry
      pbSymbiosis(self)
    end
  end
end