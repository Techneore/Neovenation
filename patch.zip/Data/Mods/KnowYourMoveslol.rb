class PokeBattle_AI
  def getAIMemory(battler=@opponent,inspecting=false)
    battler.moves
  end
end