# For those pesky moves locked in a pre-evolution, this snippet is based from AMB - Misc LearnPreEvolutionMoves.rb:
# From: Jarred aka Matt

def pbEachNaturalMove(pokemon)
  movelist=pokemon.getMoveList
  for i in movelist
    yield i[1],i[0]
  end
  preevo1 = pbGetPreviousForm(pokemon.species,pokemon.form)
  formname = $cache.pkmn[preevo1[0]].forms[preevo1[1]]
  if (!preevo1[0].nil? && !preevo1[1].nil?) && formname != "Mega" && formname != "Primal"
    if preevo1[1] == 0 || $cache.pkmn[preevo1[0]].formData.dig(formname,:Moveset).nil?
      preevo1[1] = 0
      movelist = $cache.pkmn[preevo1[0]].Moveset
    else 
      movelist = $cache.pkmn[preevo1[0]].formData.dig(formname,:Moveset)
    end
    for i in movelist
      yield i[1],i[0]
    end
  end
  preevo2 = pbGetPreviousForm(preevo1[0],preevo1[1])
  formname = $cache.pkmn[preevo2[0]].forms[preevo2[1]]
  if (!preevo2[0].nil? && !preevo2[1].nil?) && formname != "Mega" && formname != "Primal"
    if preevo2[1] == 0 || $cache.pkmn[preevo2[0]].formData.dig(formname,:Moveset).nil?
      preevo2[1] = 0
      movelist = $cache.pkmn[preevo2[0]].Moveset
    else 
      movelist = $cache.pkmn[preevo2[0]].formData.dig(formname,:Moveset)
    end
    for i in movelist
      yield i[1],i[0]
    end
  end
end