class PokemonOptions
  attr_accessor :itemRestoreReplace

  def initialize(system=nil)
    @textspeed   = (system != nil ? system.textspeed : 1)   # Text speed (0=slow, 1=mid, 2=fast)
    @volume      = (system != nil ? system.volume : 100.00) # Volume (0 - 100 )
    @sevolume    = (system != nil ? system.sevolume : 100.00) # Volume (0 - 100 )
    @audiotype   = (system != nil ? system.audiotype : 0) # Stereo / Mono audio (0 / 1)
    @bagsorttype = (system != nil ? system.bagsorttype : 0)   # Bag sorting (0=by name, 1=by type)
    @battlescene = (system != nil ? system.battlescene : 0)   # Battle scene (animations) (0=on, 1=off)
    @battlestyle = (system != nil ? system.battlestyle : 0)   # Battle style (0=shift, 1=set)
    @frame       = (system != nil ? system.frame : 0)   # Default window frame (see also TextFrames)
    @textskin    = (system != nil ? system.textskin : 0)   # Speech frame
    @font        = (system != nil ? system.font : 0)   # Font (see also VersionStyles)
    @screensize  = (system != nil ? system.screensize : (DEFAULTSCREENZOOM).floor).to_i # 0=half size, 1=full size, 2=double size
    @border      = (system != nil ? system.border : 0)   # Screen border (0=off, 1=on)
    @language    = (system != nil ? system.language : 0)   # Language (see also LANGUAGES in script PokemonSystem)
    @backup      = (system != nil ? system.backup : 0)   # Backup on/off
    @maxBackup   = (system != nil ? system.maxBackup : 50)   # Backup on/off
    @portable    = 0 #keep save files in with the game or not
    @field_effects_highlights = (system != nil ? system.field_effects_highlights : 0)   #Field effect UI highlights on/off
    @remember_commands        = (system != nil ? system.remember_commands : 0)
    @photosensitive           = (system != nil ? system.photosensitive : 0) # a mode that disables flashes and shakes (0=off, 1 = onn)
    @autorunning              = (system != nil ? system.autorunning : 0) # 0 is on, 1 is off
    @bike_and_surf_music      = (system != nil ? system.bike_and_surf_music : 0) # 0 is off, 1 is on
    @streamermode             = (system != nil ? system.streamermode : 0)
    @unrealTimeDiverge        = (system != nil ? system.unrealTimeDiverge : 0)   # Unreal Time on/off
    @unrealTimeClock          = (system != nil ? system.unrealTimeClock : 2)    # Unreal Time Clock (0=always, 1=pause menu, 2=pokegear only)
    @unrealTimeTimeScale      = (system != nil ? system.unrealTimeTimeScale : 30)   # Unreal Time Timescale (default 30x real time)
    @itemRestoreReplace				= (system != nil ? system.itemRestoreReplace : 0) #Replace/Restore Item after battle (0=No, 1=Replace, 2=Restore)
  end
end

class PokemonOptionScene
  def pbStartScene
    @sprites={}
    @viewport=Viewport.new(0,0,Graphics.width,Graphics.height)
    @viewport.z=99999
    @sprites["title"]=Window_UnformattedTextPokemon.newWithSize(
       _INTL("Options"),0,0,Graphics.width,64,@viewport)
    @sprites["textbox"]=Kernel.pbCreateMessageWindow
    @sprites["textbox"].letterbyletter=false
    #@sprites["textbox"].text=_INTL("Speech frame {1}.",1+$Settings.textskin)
    # These are the different options in the game.  To add an option, define a
    # setter and a getter for that option.  To delete an option, comment it out
    # or delete it.  The game's options may be placed in any order.
    if $game_switches && $game_switches[:Unreal_Time]
      utOpt1 = EnumOption.new(_INTL("Unreal Time"),[_INTL("Off"),_INTL("On")],
        proc { $Settings.unrealTimeDiverge},
        proc {|value|  $Settings.unrealTimeDiverge=value },
        "Uses in-game time instead of computer clock."
      )
      utOpt2 = EnumOption.new(_INTL("Show Clock"),[_INTL("Always"),_INTL("Menu"),_INTL("Gear")],
        proc { $Settings.unrealTimeClock},
        proc {|value|  $Settings.unrealTimeClock=value },
        "Shows an in-game clock that displays the current time."
      )
      utOpt3 = NumberOption.new(_INTL("Unreal Time Scale"),_INTL("Type %d"),1,60,
        proc { $Settings.unrealTimeTimeScale-1 },
        proc {|value|  $Settings.unrealTimeTimeScale=value+1 },
        "Sets the rate at which unreal time passes."
      )
      unless OptionList.any? {|opt| opt.name == "Unreal Time" }
        OptionList.push(utOpt1)
        OptionList.push(utOpt2)
        OptionList.push(utOpt3)
      end
    end
    if ITEMRESTOREREPLACE
      utOpt4 = EnumOption.new(_INTL("Item Restore/Replace"),[_INTL("Off"),_INTL("Replace"),_INTL("Restore")],
        proc { $Settings.itemRestoreReplace},
        proc {|value|  $Settings.itemRestoreReplace=value },
        "Choses if the items will be restored after battle or just replaced from the bag."
      )
      unless OptionList.any? {|opt| opt.name == "Item Restore/Replace" }
        OptionList.push(utOpt4)
      end
    end
    @sprites["option"]=Window_PokemonOption.new(OptionList,0,
       @sprites["title"].height,Graphics.width,
       Graphics.height-@sprites["title"].height-@sprites["textbox"].height)
    @sprites["option"].viewport=@viewport
    @sprites["option"].visible=true
    # Get the values of each option
    for i in 0...OptionList.length
      @sprites["option"][i]=(OptionList[i].get || 0)
    end
    pbDeactivateWindows(@sprites)
    pbFadeInAndShow(@sprites) { pbUpdate }
  end
end
