###### MOD ######
class ChangeClothesPC
  def shouldShow?
    return true
  end

  def name
    return _INTL("Change Clothes")
  end

  def access
    if ($Trainer.metaID == 0 || $Trainer.metaID == 1 || $Trainer.metaID == 4 || $Trainer.metaID == 5 || $Trainer.metaID == 6 || $Trainer.metaID == 7 || $Trainer.metaID == 8) && 
      ($Trainer.outfit == 0 || $Trainer.outfit == 1 || $Trainer.outfit == 2  || ($Trainer.outfit == 6 && $game_switches[1645])) #XG OUTFIT AVAILABLE switch
      if $game_variables[246] > 10 #Post8thBadge variable. Unlocks Seconday outfit
        if $game_switches[1052] #LEGACYSKINS switch. Unlocks Legacy outfit
          if $game_switches[1645] #XG OUTFIT AVAILABLE switch. Unlocks Xenogene outfit
            choice=Kernel.pbMessage(
              _INTL('Do you wish to change clothes?'),
              [
                _INTL('Normal outfit'),
                _INTL('Secondary outfit'),
                _INTL('Legacy outfit'),
                _INTL('Xenogene outfit'),
                _INTL("Don't change clothes.")
              ],
              5
            )
            case choice
            when 0
              $game_variables[259]=0
              $Trainer.outfit=0
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your normal outfit."))
              return
            when 1
              $game_variables[259]=1
              $Trainer.outfit=1
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your secondary outfit."))
              return 
            when 2
              $game_variables[259]=2
              $Trainer.outfit=2
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your legacy outfit."))
              return
            when 3
              $game_variables[259]=6
              $Trainer.outfit=6
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your xenogene outfit."))
              return
            end
            return 0
          else
            choice=Kernel.pbMessage(
              _INTL('Do you wish to change clothes?'),
              [
                _INTL('Normal outfit'),
                _INTL('Secondary outfit'),
                _INTL('Legacy outfit'),
                _INTL("Don't change clothes.")
              ],
              4
            )
            case choice
            when 0
              $game_variables[259]=0
              $Trainer.outfit=0
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your normal outfit."))
              return
            when 1
              $game_variables[259]=1
              $Trainer.outfit=1
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your secondary outfit."))
              return 
            when 2
              $game_variables[259]=2
              $Trainer.outfit=2
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your legacy outfit."))
              return
            end
            return 0
          end
        else
          if $game_switches[1645] #XG OUTFIT AVAILABLE switch. Unlocks Xenogene outfit
            choice=Kernel.pbMessage(
              _INTL('Do you wish to change clothes?'),
              [
                _INTL('Normal outfit'),
                _INTL('Secondary outfit'),
                _INTL('Xenogene outfit'),
                _INTL("Don't change clothes.")
              ],
              4
            )
            case choice
            when 0
              $game_variables[259]=0
              $Trainer.outfit=0
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your normal outfit."))
              return
            when 1
              $game_variables[259]=1
              $Trainer.outfit=1
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your secondary outfit."))
              return
            when 2
               $game_variables[259]=6
               $Trainer.outfit=6
               Kernel.pbMessage(_INTL("\\se[Fire1]You put your xenogene outfit."))
               return
            end
            return 0
          else
            choice=Kernel.pbMessage(
              _INTL('Do you wish to change clothes?'),
              [
                _INTL('Normal outfit'),
                _INTL('Secondary outfit'),
                _INTL("Don't change clothes.")
              ],
              3
            )
            case choice
            when 0
              $game_variables[259]=0
              $Trainer.outfit=0
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your normal outfit."))
              return
            when 1
              $game_variables[259]=1
              $Trainer.outfit=1
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your secondary outfit."))
              return 
            end
            return 0
          end
        end
      elsif $game_switches[1052] #LEGACYSKINS switch. Unlocks Legacy outfit
          choice=Kernel.pbMessage(
            _INTL('Do you wish to change clothes?'),
            [
              _INTL('Normal outfit'),
              _INTL('Legacy outfit'),
              _INTL("Don't change clothes.")
            ],
            3
          )
          case choice
            when 0
              $game_variables[259]=0
              $Trainer.outfit=0
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your normal outfit."))
              return
            when 1
              $game_variables[259]=2
              $Trainer.outfit=2
              Kernel.pbMessage(_INTL("\\se[Fire1]You put your legacy outfit."))
              return
            end
          return 0
      else
        Kernel.pbMessage(_INTL("You don't have other outfits."))
      end
    else
      Kernel.pbMessage(_INTL("You can't change outfits now."))
    end
  end
end

PokemonPCList.registerPC(ChangeClothesPC.new)
###### MOD ######
