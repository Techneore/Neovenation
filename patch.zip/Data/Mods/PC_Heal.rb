###### MOD ######
class HealPC
  def shouldShow?
    return true
  end

  def name
    return _INTL("Heal Function")
  end

  def access
    Kernel.pbMessage(_INTL("\\se[accesspc]The PC Heal function has healed your party."))
    pbHealAll
  end
end

PokemonPCList.registerPC(HealPC.new)
###### MOD ######
