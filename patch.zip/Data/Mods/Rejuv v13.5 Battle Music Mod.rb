def bmp_allowOverride?(trainer)
  #return true if !trainer.is_a?(Array) && trainer.trainertype == PBTrainers::XYZ && $game_map.map_id == 123
  return true if $game_map.map_id == 53 || $game_map.map_id == 57 || $game_map.map_id == 70 || $game_map.map_id == 85 || $game_map.map_id == 113 || $game_map.map_id == 126 || $game_map.map_id == 135 || $game_map.map_id == 169 ||
                 $game_map.map_id == 225 || $game_map.map_id == 232 || $game_map.map_id == 237 || $game_map.map_id == 300 || $game_map.map_id == 316 || $game_map.map_id == 343 || $game_map.map_id == 381 || $game_map.map_id == 389 ||
                 $game_map.map_id == 408 || $game_map.map_id == 424 || $game_map.map_id == 428 || $game_map.map_id == 449 || $game_map.map_id == 455 || $game_map.map_id == 456 || $game_map.map_id == 466 || $game_map.map_id == 518 ||
                 $game_map.map_id == 525 || $game_map.map_id == 539 || $game_map.map_id == 551 || $game_map.map_id == 552 || $game_map.map_id == 573 || $game_map.map_id == 586 || $game_map.map_id == 607 || $game_map.map_id == 616
  return false
end

def pbGetTrainerBattleBGM(trainer) # can be a PokeBattle_Trainer or an array of PokeBattle_Trainer
  ####MODDED
  if $PokemonGlobal.nextBattleBGM && bmp_allowOverride?(trainer)
  ####/MODDED
    return $PokemonGlobal.nextBattleBGM.clone
  end
  music=nil
  trainerarray=trainer
  trainerarray=[trainer] if !trainer.is_a?(Array)
  for i in 0...trainerarray.length
    trainertype=trainerarray[i].trainertype
    if $cache.trainertypes[trainertype]
      music=$cache.trainertypes[trainertype].checkFlag?(:battleBGM)
      music=$cache.trainertypes[trainertype].battleBGM
    end
  end
  return pbStringToAudioFile(music) if music && music!=""
  music=$cache.mapdata[$game_map.map_id].TrainerBattleBGM
  return pbStringToAudioFile(music) if music
  music=$cache.metadata[:TrainerBattle]
  return pbStringToAudioFile(music) if music
  return nil
end