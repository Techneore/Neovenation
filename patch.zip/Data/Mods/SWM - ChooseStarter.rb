class Game_Map
  def swm_checkStarterRoom
    $swm_starterRoomId=304
  end
  def swm_playerInStarterRoom?
    return false if !defined?($swm_starterRoomId) || !$swm_starterRoomId
    return false if $Trainer.numbadges > 0
    return false if $game_variables[659] > 6
    return @map_id == $swm_starterRoomId
  end
end
class PokemonScreen
  def swm_handleStarterChange
    $game_map.swm_checkStarterRoom()
    return nil if !$game_map.swm_playerInStarterRoom?
    Kernel.pbMessage(_INTL('It is possible to choose any starter species or reroll your starter before speaking with Amanda.'))
    choice=Kernel.pbMessage(
      _INTL('Would you like to do so now?'),
      [
        _INTL('Choose Starter'),
        _INTL('Reroll Starter'),
        _INTL('No')
      ],
      3
    )
    swm_changeSpecies if choice == 0
    swm_rerollSpecies if choice == 1
  end
  def swm_changeSpecies
    pkmn=@party[0]
    newSpecies, newForm=swm_getNewSpecies(pkmn.species)
    return nil if !newSpecies
    oldSpecies=pkmn.species
    swm_updateOwned(oldSpecies, newSpecies)
    swm_updateMon(pkmn, oldSpecies, newSpecies, newForm)
  end

  def swm_rerollSpecies
    pkmn=@party[0]
    newSpecies=pkmn.species
    newForm=pkmn.form
    return nil if !newSpecies
    oldSpecies=pkmn.species
    swm_updateOwned(oldSpecies, newSpecies)
    swm_updateMon(pkmn, oldSpecies, newSpecies, newForm)
  end

  def swm_getNewSpecies(oldSpecies)
    return swm_chooseSpecies(oldSpecies)
  end

  def swm_chooseSpecies(oldSpecies)
    species=pbChooseSpeciesOrdered(0)
    if PBStuff::LEGENDARYLIST.include?(species) || PBStuff::ULTRABEASTS.include?(species) || species == :DRACOZOLT || species == :ARCTOZOLT || species == :DRACOVISH || species == :ARCTOVISH || species == :IRONMOTH
      Kernel.pbMessage(_INTL("You cannot choose {1} as s starter", species))
    else
      if species
        babyspecies=pbGetBabySpecies(species, 0)
        if (babyspecies[0] == :MUNCHLAX) && species == :SNORLAX
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :WYNAUT) && species == :WOBBUFFET
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :HAPPINY) && species == :CHANSEY
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :HAPPINY) && species == :BLISSEY
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :MIMEJR) && species == :MRMIME
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :MIMEJR) && species == :MRRIME
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :CHINGLING) && species == :CHIMECHO
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :BONSLY) && species == :SUDOWOODO
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :BUDEW) && species == :ROSELIA
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :BUDEW) && species == :ROSERADE
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :AZURILL) && species == :MARILL
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :AZURILL) && species == :AZUMARILL
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        elsif (babyspecies[0] == :MANTYKE) && species == :MANTINE
          babyspecies=pbGetNonIncenseLowestSpecies(babyspecies[0],babyspecies[1])
        end
        formMin=0
        formMax=0
        formname0=" Normal Form"
        formname1=" "
        formname2=" "
        formname3=" "
        formname4=" "
        formname5=" "
        formname6=" "
        formHelp0="0:Normal"
        formHelp1=""
        formHelp2=""
        formHelp3=""
        formHelp4=""
        formHelp5=""
        formHelp6=""
        #Allow Regional Forms
        if babyspecies[0] == :RATTATA || babyspecies[0] == :SANDSHREW || babyspecies[0] == :VULPIX || babyspecies[0] == :DIGLETT || babyspecies[0] == :GEODUDE || babyspecies[0] == :GRIMER 
          formMax=1
          formname1="n Alolan Form"
          formHelp1=" 1:Alolan"
        end
        if babyspecies[0] == :MEOWTH 
          formMax=2
          formname1="n Alolan Form"
          formname2=" Galarian Form"
          formHelp1=" 1:Alolan"
          formHelp2=" 2:Galarian"
        end
        if babyspecies[0] == :PONYTA || babyspecies[0] == :SLOWPOKE || babyspecies[0] == :FARFETCHD || babyspecies[0] == :MRMIME || babyspecies[0] == :CORSOLA || babyspecies[0] == :ZIGZAGOON || babyspecies[0] == :DARUMAKA  || babyspecies[0] == :YAMASK || babyspecies[0] == :STUNKFISK  
          formMax=1
          formname1=" Galarian Form"
          formHelp1=" 1:Galarian"
        end
        if babyspecies[0] == :PARAS || babyspecies[0] == :MAGIKARP || babyspecies[0] == :LAPRAS || babyspecies[0] == :MAREEP || babyspecies[0] == :MISDREAVUS || babyspecies[0] == :SHROOMISH || babyspecies[0] == :ROSELIA || babyspecies[0] == :FEEBAS || babyspecies[0] == :SNORUNT || babyspecies[0] == :BUDEW || babyspecies[0] == :BRONZOR || babyspecies[0] == :MUNNA || babyspecies[0] == :SEWADDLE || babyspecies[0] == :SIGILYPH || babyspecies[0] == :LITWICK || babyspecies[0] == :LARVESTA || babyspecies[0] == :WIMPOD || babyspecies[0] == :JANGMOO  
          formMax=1
          formname1=" Aevian Form"
          formHelp1=" 1:Aevian"
        end
        if babyspecies[0] == :SHELLOS 
          formMax=3
          formname0=" West Sea"
          formname1=" East Sea"
          formHelp0=" 0:West Sea"
          formHelp1=" 1:East Sea"
          formname2=" West Aevian Form"
          formname3=" East Aevian Form"
          formHelp2=" 2:West Aevian"
          formHelp3=" 3:East Aevian"
        end
        if babyspecies[0] == :GROWLITHE || babyspecies[0] == :VOLTORB || babyspecies[0] == :QWILFISH || babyspecies[0] == :SNEASEL || babyspecies[0] == :ZORUA 
          formMax=1
          formname1=" Hisuian Form"
          formHelp1=" 1:Hisuian"
        end
        #Allow ordinary forms
        if babyspecies[0] == :BURMY
          formMax=2
          formname0=" Plant Cloak"
          formHelp0=" 0:Plant Cloak"
          formname1=" Sandy Cloak"
          formHelp1=" 1:Sandy Cloak"
          formname2=" Trash Cloak"
          formHelp2=" 2:Trash Cloak"
        end
        if babyspecies[0] == :BASCULIN
          formMax=2
          formname0=" Red-Striped"
          formHelp0=" 0:Red-Striped"
          formname1=" Blue-Striped"
          formHelp1=" 1:Blue-Striped"
          formname2=" White-Striped"
          formHelp2=" 2:White-Striped"
        end
        if babyspecies[0] == :DEERLING
          formMax=3
          formname0=" Spring Form"
          formHelp0=" 0:Spring"
          formname1=" Summer Form"
          formHelp1=" 1:Summer"
          formname2=" Autumn Form"
          formHelp2=" 2:Autumn"
          formname3=" Winter Form"
          formHelp3=" 3:Winter"
        end
        if babyspecies[0] == :PUMPKABOO
          formMax=1
          formname1=" Small"
          formHelp1=" 1:Small"
        end
        if babyspecies[0] == :ORICORIO
          formMax=3
          formname0=" Balie Style"
          formHelp0=" 0:Baile"
          formname1=" Pom-Pom Style"
          formHelp1=" 1:Pom-Pom"
          formname2=" Pa'u Style"
          formHelp2=" 2:Pa'u"
          formname3=" Sensu Style"
          formHelp3=" 3:Sensu"
        end
        if babyspecies[0] == :MINIOR
          formMax=6
          formname0=" Red Core"
          formHelp0=" 0:Red"
          formname1=" Blue Core"
          formHelp1=" 1:Blue"
          formname2=" Green Core"
          formHelp2=" 2:Green"
          formname3=" Violet Core"
          formHelp3=" 3:Violet"
          formname4=" White Core"
          formHelp4=" 4:White"
          formname5=" Yellow Core"
          formHelp5=" 5:Yellow"
          formname6=" Dark Core"
          formHelp6=" 6:Dark"
        end
        if babyspecies[0] == :FLABEBE
          formMax=4
          formname0=" Red Flower"
          formHelp0=" 0:Red"
          formname1=" Blue Flower"
          formHelp1=" 1:Blue"
          formname2=" Black Flower"
          formHelp2=" 2:Black"
          formname3=" Green Flower"
          formHelp3=" 3:Green"
          formname4=" Purple Flower"
          formHelp4=" 4:Purple"
        end
        formInit=babyspecies[1]
        params=ChooseNumberParams.new
        params.setRange(formMin,formMax)
        params.setInitialValue(formInit)
        params.setCancelValue(10)
        if formMax != 0
          babyspecies[1]=Kernel.pbMessageChooseNumber(_INTL("{1}{2}{3}{4}{5}{6}{7}",formHelp0,formHelp1,formHelp2,formHelp3,formHelp4,formHelp5,formHelp6),params)
        end
        if babyspecies[1] == 0
          formname = formname0
        elsif babyspecies[1] == 1
          formname = formname1
        elsif babyspecies[1] == 2
          formname = formname2
        elsif babyspecies[1] == 3
          formname = formname3
        elsif babyspecies[1] == 4
          formname = formname4
        elsif babyspecies[1] == 5
          formname = formname5
        elsif babyspecies[1] == 6
          formname = formname6
        elsif babyspecies[1] == 10
          return
        else formname = " "
        end
        if Kernel.pbConfirmMessage(_INTL("Receive a{2} {1} as starter?", babyspecies[0], formname))
          return babyspecies[0],babyspecies[1]
        end
      end
    end
  end
  def swm_updateOwned(oldSpecies, newSpecies)
    $Trainer.pokedex.dexList[oldSpecies][:seen?]=false
    $Trainer.pokedex.dexList[oldSpecies][:owned?]=false
  end
  def swm_updateMon(pkmn, oldSpecies, newSpecies, newForm)
    pbAddPokemon(newSpecies,5,true,newForm)
    @party[0]=nil
    @party.compact!
  end
  if !defined?(swm_chooseStarter_oldPbPokemonScreen)
    alias :swm_chooseStarter_oldPbPokemonScreen :pbPokemonScreen
  end
  #####/MODDED
  
  def pbPokemonScreen(*args, **kwargs)
    swm_handleStarterChange
    return swm_chooseStarter_oldPbPokemonScreen(*args, **kwargs)
  end
end