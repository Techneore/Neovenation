#####MODDED
HiddenMoveHandlers::CanUseMove.add(:REST,lambda{|move,pkmn|
   return true # swm_canRest?()
})

HiddenMoveHandlers::UseMove.add(:REST,lambda{|move,pokemon|
   if !pbHiddenMoveAnimation(pokemon)
     Kernel.pbMessage(_INTL("{1} used {2}.",pokemon.name,getMoveName(move)))
   end
   swm_pbRest
   return true
})
#####/MODDED