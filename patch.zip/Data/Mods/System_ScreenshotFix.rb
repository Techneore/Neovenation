module Input
  unless defined?(update_KGC_ScreenCapture)
    class << Input
      alias update_KGC_ScreenCapture update
    end
  end

  def self.update
    update_KGC_ScreenCapture
    if triggerex?(:F8)
      pbScreenCapture
    end
    if triggerex?(:LALT) || (triggerex?(:M) && Input.text_input != true) || triggerex?(:RALT)
      pbTurbo()
    end
    if triggerex?(:F7)
      if $game_system
        $game_system.toggle_mute
      end
    end
    if triggerex?(:F10) && $DEBUG
      if $is_profile != true
        $is_profile = true
        Kernel.pbMessage("Begin profiling")
        CP_Profiler.begin
      end
    end
    if triggerex?(:F11) && $DEBUG
      CP_Profiler.print
      $is_profile = false
    end
    if triggerex?(:F6) && $DEBUG
      begin
        Input.text_input = true
        code = Kernel.pbMessageFreeText(_INTL("What code would you like to run?"),"",false,999,500)
        eval(code)
        Input.text_input = false
      rescue
        pbPrintException($!)
        Input.text_input = false
      end
    end
  end
end