class PokeBattle_Move

################################################################################
# This move's accuracy check
################################################################################
  def pbAccuracyCheck(attacker,opponent)
    baseaccuracy=self.accuracy
    # Field Effects
    fieldmove = @battle.field.moveData(@move)
    baseaccuracy = fieldmove[:accmod] if fieldmove && fieldmove[:accmod]
    return true if baseaccuracy==0
    return true if attacker.ability == :NOGUARD || opponent.ability == :NOGUARD || (attacker.ability == (:FAIRYAURA) && @battle.FE == :FAIRYTALE)
    return true if opponent.effects[:Telekinesis]>0
    return true if @function==0x0D && @battle.pbWeather== :HAIL # Blizzard
    return true if (@function==0x08 || @function==0x15) && @battle.pbWeather== :RAINDANCE # Thunder, Hurricane
    return true if @type == :ELECTRIC && @battle.FE == :UNDERWATER
    return true if attacker.hasType?(:POISON) && @move == :TOXIC
    return true if (@function==0x10 || @move == :BODYSLAM ||
                    @function==0x137 || @function==0x9B) &&
                    opponent.effects[:Minimize] # Flying Press, Stomp, DRush
    return true if @battle.FE == :MIRROR && (PBFields::BLINDINGMOVES + [:MIRRORSHOT]).include?(@move)
    # One-hit KO accuracy handled elsewhere
    if @function==0x08 || @function==0x15 # Thunder, Hurricane
      baseaccuracy=50 if (@battle.pbWeather== :SUNNYDAY && !attacker.hasWorkingItem(:UTILITYUMBRELLA))
    end
    accstage=attacker.stages[PBStats::ACCURACY]
    accstage=0 if opponent.ability == :UNAWARE && !(opponent.moldbroken)
    accuracy=(accstage>=0) ? (accstage+3)*100.0/3 : 300.0/(3-accstage)
    evastage=opponent.stages[PBStats::EVASION]
    evastage-=2 if @battle.state.effects[:Gravity]!=0
    evastage=-6 if evastage<-6
    evastage=0 if opponent.effects[:Foresight] || opponent.effects[:MiracleEye] || @function==0xA9 || # Chip Away
                  attacker.ability == :UNAWARE && !(opponent.moldbroken)
    evasion=(evastage>=0) ? (evastage+3)*100.0/3 : 300.0/(3-evastage)
    if attacker.ability == :COMPOUNDEYES
      accuracy*=1.3
    end
    if attacker.hasWorkingItem(:MICLEBERRY)
      if (attacker.ability == :GLUTTONY && attacker.hp<=(attacker.totalhp/2.0).floor) ||
        attacker.hp<=(attacker.totalhp/4.0).floor
        accuracy*=1.2
        attacker.pbDisposeItem(true)
      end
    end
    if attacker.ability == :VICTORYSTAR
      accuracy*=1.1
    end
    partner=attacker.pbPartner
    if partner && partner.ability == :VICTORYSTAR
      accuracy*=1.1
    end
    if attacker.hasWorkingItem(:WIDELENS)
      accuracy*=1.1
    end
    # Hypno Crest, Stantler Crest
    if [:HYPNO,:STANTLER,:WYRDEER].include?(attacker.crested)
      accuracy *= 1.5
    end
    if baseaccuracy>70
      accuracy *= 1.2
    else
      accuracy *= 1.3
    end 
    if attacker.hasWorkingItem(:ZOOMLENS) && attacker.speed < opponent.speed
      accuracy*=1.2
    end
    if attacker.ability == :HUSTLE && @basedamage>0 && pbIsPhysical?(pbType(attacker))
      accuracy*= [:BACKALLEY,:CITY].include?(@battle.FE) ? 0.67 : 0.8
    end
    if attacker.ability == :LONGREACH && (@battle.FE == :ROCKY || (!Rejuv && @battle.FE == :FOREST)) # Rocky/ Forest Field
      accuracy*=0.9
    end
    if (opponent.ability == :WONDERSKIN || (Rejuv && @battle.FE == :PSYTERRAIN && opponent.ability == :MAGICIAN)) && 
      @basedamage==0 && attacker.pbIsOpposing?(opponent.index) && !(opponent.moldbroken)
      if @battle.FE == :RAINBOW
        accuracy*=0
      else
        accuracy*=0.5
      end
    end
    if opponent.ability == :TANGLEDFEET && opponent.effects[:Confusion]>0 && !(opponent.moldbroken)
      evasion*=1.2
    end
    if opponent.ability == :SANDVEIL && (@battle.pbWeather== :SANDSTORM || @battle.FE == :DESERT || @battle.FE == :ASHENBEACH) && !(opponent.moldbroken)
      evasion*=1.2
    end
    if opponent.ability == :SNOWCLOAK && (@battle.pbWeather== :HAIL || @battle.FE == :ICY || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :FROZENDIMENSION) && !(opponent.moldbroken)
      evasion*=1.2
    end
    if opponent.hasWorkingItem(:BRIGHTPOWDER)
      evasion*=1.1
    end
    if opponent.hasWorkingItem(:LAXINCENSE)
      evasion*=1.1
    end
    evasion = 100 if attacker.ability == :KEENEYE
    evasion = 100 if @battle.FE == :ASHENBEACH && (attacker.ability == :OWNTEMPO || attacker.ability == :INNERFOCUS || attacker.ability == :PUREPOWER || attacker.ability == :SANDVEIL || attacker.ability == :STEADFAST) && (opponent.ability != :UNNERVE || opponent.ability != :ASONE)
    return @battle.pbRandom(100)<(baseaccuracy*accuracy/evasion)
  end
  
end  