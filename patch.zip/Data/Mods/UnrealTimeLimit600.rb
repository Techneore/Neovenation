class PokemonOptionScene
  def pbStartScene
    @sprites={}
    @viewport=Viewport.new(0,0,Graphics.width,Graphics.height)
    @viewport.z=99999
    @sprites["title"]=Window_UnformattedTextPokemon.newWithSize(
       _INTL("Options"),0,0,Graphics.width,64,@viewport)
    @sprites["textbox"]=Kernel.pbCreateMessageWindow
    @sprites["textbox"].letterbyletter=false
    #@sprites["textbox"].text=_INTL("Speech frame {1}.",1+$Settings.textskin)
    # These are the different options in the game.  To add an option, define a
    # setter and a getter for that option.  To delete an option, comment it out
    # or delete it.  The game's options may be placed in any order.
    if $game_switches && $game_switches[:Unreal_Time]
      utOpt1 = EnumOption.new(_INTL("Unreal Time"),[_INTL("Off"),_INTL("On")],
        proc { $Settings.unrealTimeDiverge},
        proc {|value|  $Settings.unrealTimeDiverge=value },
        "Uses in-game time instead of computer clock."
      )
      utOpt2 = EnumOption.new(_INTL("Show Clock"),[_INTL("Always"),_INTL("Menu"),_INTL("Gear")],
        proc { $Settings.unrealTimeClock},
        proc {|value|  $Settings.unrealTimeClock=value },
        "Shows an in-game clock that displays the current time."
      )
      utOpt3 = NumberOption.new(_INTL("Unreal Time Scale"),_INTL("Type %d"),1,600,
        proc { $Settings.unrealTimeTimeScale-1 },
        proc {|value|  $Settings.unrealTimeTimeScale=value+1 },
        "Sets the rate at which unreal time passes."
      )
      unless OptionList.any? {|opt| opt.name == "Unreal Time" }
        OptionList.push(utOpt1)
        OptionList.push(utOpt2)
        OptionList.push(utOpt3)
      end
    end
    if ITEMRESTOREREPLACE
      utOpt4 = EnumOption.new(_INTL("Item Restore/Replace"),[_INTL("Off"),_INTL("Replace"),_INTL("Restore")],
        proc { $Settings.itemRestoreReplace},
        proc {|value|  $Settings.itemRestoreReplace=value },
        "Choses if the items will be restored after battle or just replaced from the bag."
      )
      unless OptionList.any? {|opt| opt.name == "Item Restore/Replace" }
        OptionList.push(utOpt4)
      end
    end
    @sprites["option"]=Window_PokemonOption.new(OptionList,0,
       @sprites["title"].height,Graphics.width,
       Graphics.height-@sprites["title"].height-@sprites["textbox"].height)
    @sprites["option"].viewport=@viewport
    @sprites["option"].visible=true
    # Get the values of each option
    for i in 0...OptionList.length
      @sprites["option"][i]=(OptionList[i].get || 0)
    end
    pbDeactivateWindows(@sprites)
    pbFadeInAndShow(@sprites) { pbUpdate }
  end
end