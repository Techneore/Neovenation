class Pokedex
  alias :autodex_old_setOwned :setOwned

  def setOwned(pokemon)
    return if !pokemon.is_a?(PokeBattle_Pokemon)
    if $game_switches
      return if $game_switches[:NotPlayerCharacter]
    end

    autodex_old_setOwned(pokemon)
    for mon in AutoDex.getPokemonAncestors(pokemon)
      autodex_old_setOwned(mon)
    end
    for mon in AutoDex.getPokemonDescendents(pokemon)
      autodex_old_setOwned(mon)
    end
    for mon in AutoDex.getAdditionalPokemon(pokemon)
      autodex_old_setOwned(mon)
    end
  end
end

module AutoDex

  def self.getPokemonAncestors(pokemon)
    mons = []
    prevo = pokemon
    while !prevo.nil?
      prevoSpecies = pbGetPreviousForm(prevo.species,prevo.form)
      if prevoSpecies[0] == prevo.species and prevoSpecies[1] == prevo.form
        prevo = nil
      else
        prevo=PokeBattle_Pokemon.new(prevoSpecies[0],prevo.level,$Trainer,false,form=prevoSpecies[1])
        mons.push(prevo)
      end
    end

    return mons  
  end

  def self.getPokemonDescendents(pokemon)
    mons = []
    processed = []
    toprocess = [pokemon]
    while !toprocess.empty?
      process = toprocess.pop
      processed.push([process.species, process.form])
      evolvedData = pbGetEvolvedFormData(process.species, process)
      if evolvedData
        for evo in evolvedData
          species = evo[0]
          if $cache.pkmn[species] # handle eviolite-dummy sableye
            item = nil
            item = evo[2] if [:Item, :TradeItem, :Trade, :ItemMale, :ItemFemale, :DayHoldItem, :NightHoldItem].include?(evo[1])
            form = getEvolutionForm(process, item)

            unless processed.include?([species, form])
              evomon=PokeBattle_Pokemon.new(species,pokemon.level,$Trainer,false,form)
              mons.push(evomon)
              toprocess.push(evomon)
            end
          end
        end
      end
    end
    
    return mons
  end

  def self.getAdditionalPokemon(pokemon)
    if [:NIDORANfE, :NIDORINA, :NIDOQUEEN, :NIDORANmA, :NIDORINO, :NIDOKING].include?(pokemon.species)
      otherspecies = pokemon.gender == 0 ? :NIDORANfE : :NIDORANmA
      return [PokeBattle_Pokemon.new(otherspecies, pokemon.level)]
    elsif [:VOLBEAT, :ILLUMISE].include?(pokemon.species)
      otherspecies = pokemon.gender == 0 ? :ILLUMISE : :VOLBEAT
      return [PokeBattle_Pokemon.new(otherspecies, pokemon.level)]
    elsif pokemon.species == :MANAPHY
      return [PokeBattle_Pokemon.new(:PHIONE, pokemon.level)]
    end

    return []
  end
end

alias :autodex_old_pbPurify :pbPurify

def pbPurify(pokemon,scene)
  setowned = pokemon.heartgauge==0 && pokemon.shadow && (pokemon.savedev || pokemon.savedexp)
  ret = autodex_old_pbPurify(pokemon, scene)
  $Trainer.pokedex.setOwned(pokemon) if setowned
  return ret
end