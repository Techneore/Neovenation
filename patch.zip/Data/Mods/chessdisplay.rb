# Piece graphics adapted from https://berryarray.itch.io/chess-pieces-16x16-one-bit

def pbChessRoles(party, doublebattle)
  return if party.length == 0
  chessmap = {}
  pkmnparty = party.find_all {|mon| !mon.nil? && !mon.isEgg? }
  pkmnparty.each {|pkmn| pkmn.piece = nil}
  # Queen
  pkmnparty.last.piece = :QUEEN
  # Pawn
  sendoutorder = pkmnparty.find_all {|mon| mon.hp > 0}
  sendoutorder[0].piece = :PAWN if sendoutorder[0].piece.nil?
  sendoutorder[1].piece = :PAWN if sendoutorder[1] && doublebattle && sendoutorder[1].piece.nil? 
  # King
  king_piece = pkmnparty.sort_by { |mon| [mon.piece.nil? ? 0 : 1, mon.item==:KINGSROCK ? 0 : 1, mon.totalhp] }.first
  king_piece.piece = :KING if king_piece && king_piece.piece.nil?
  # Knight / Bishop / Rook
  pkmnparty.each do |pkmn|
    next if pkmn.piece
    pkmn.piece = :KNIGHT if [pkmn.speed,pkmn.attack,pkmn.spatk,pkmn.defense,pkmn.spdef].max == pkmn.speed
    pkmn.piece = :BISHOP if [pkmn.speed,pkmn.attack,pkmn.spatk,pkmn.defense,pkmn.spdef].max == [pkmn.attack,pkmn.spatk].max
    pkmn.piece = :ROOK   if [pkmn.speed,pkmn.attack,pkmn.spatk,pkmn.defense,pkmn.spdef].max == [pkmn.defense,pkmn.spdef].max
  end
end

class PokeSelectionSprite
  def initialize(pokemon,index,viewport=nil)
    super(viewport)
    @pokemon=pokemon
    active=(index==0)
    @active=active
    @deselbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanel")
    @selbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanelSel")
    @deselfntbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanelFnt")
    @selfntbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanelSelFnt")
    @deselswapbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanel")
    @selswapbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanelSel")
    @deselswapfntbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanelFnt")
    @selswapfntbitmap=AnimatedBitmap.new("Graphics/Pictures/Party/partyPanelSelFnt")
    @spriteXOffset=28
    @spriteYOffset=0
    @pokeballXOffset=10
    @pokeballYOffset=0
    @pokenameX=96
    @pokenameY=16
    @levelX=20
    @levelY=68
    @statusX=80
    @statusY=68
    @genderX=224
    @genderY=16
    @hpX=224
    @hpY=60
    @hpbarX=96
    @hpbarY=50
    @gaugeX=128
    @gaugeY=52
    @itemXOffset=62
    @itemYOffset=48
    @annotX=96
    @annotY=58
    @pieceX=@selbitmap.width - 32
    @pieceY=64
    xvalues=[0,256,0,256,0,256]
    yvalues=[0,16,96,112,192,208]
    @text=nil
    @pkmnsprite=PokemonIconSprite.new(pokemon,viewport)
    @pkmnsprite.active=active
    @statuses=AnimatedBitmap.new(_INTL("Graphics/Pictures/statuses"))
    @hpbar=AnimatedBitmap.new("Graphics/Pictures/Party/partyHP")
    @hpbarfnt=AnimatedBitmap.new("Graphics/Pictures/Party/partyHPfnt")
    @hpbarswap=AnimatedBitmap.new("Graphics/Pictures/Party/partyHP")
    @hpbarswapfnt=AnimatedBitmap.new("Graphics/Pictures/Party/partyHPfnt")
    @pokeballsprite=ChangelingSprite.new(0,0,viewport)
    @pokeballsprite.addBitmap("pokeballdesel","Graphics/Pictures/Party/partyBall")
    @pokeballsprite.addBitmap("pokeballsel","Graphics/Pictures/Party/partyBallSel")
    @itemsprite=ChangelingSprite.new(0,0,viewport)
    @itemsprite.addBitmap("itembitmap","Graphics/Pictures/Party/item")
    @itemsprite.addBitmap("mailbitmap","Graphics/Pictures/Party/mail")
    ### MODDED/
    @pieces=AnimatedBitmap.new(_INTL("Data/Mods/chesspieces"))
    ### /MODDED
    @spriteX=xvalues[index]
    @spriteY=yvalues[index]
    @refreshBitmap=true
    @refreshing=false 
    @preselected=false
    @switching=false
    @pkmnsprite.z=self.z+2 # For compatibility with RGSS2
    @itemsprite.z=self.z+3 # For compatibility with RGSS2
    @pokeballsprite.z=self.z+1 # For compatibility with RGSS2
    self.selected=false
    self.x=@spriteX
    self.y=@spriteY
    refresh
  end

  def dispose
    ### MODDED/
    @pieces.dispose
    ### /MODDED
    @selbitmap.dispose
    @statuses.dispose
    @hpbar.dispose
    @deselbitmap.dispose
    @itemsprite.dispose
    @pkmnsprite.dispose
    @pokeballsprite.dispose
    self.bitmap.dispose
    super
  end

  def refresh
    return if @refreshing
    return if disposed?
    @refreshing=true
    if !self.bitmap || self.bitmap.disposed?
      self.bitmap=BitmapWrapper.new(@selbitmap.width,@selbitmap.height)
    end
    if @pkmnsprite && !@pkmnsprite.disposed?
      @pkmnsprite.x=self.x+@spriteXOffset
      @pkmnsprite.y=self.y+@spriteYOffset
      @pkmnsprite.color=pbSrcOver(@pkmnsprite.color,self.color)
      @pkmnsprite.selected=self.selected
    end
    if @pokeballsprite && !@pokeballsprite.disposed?
      @pokeballsprite.x=self.x+@pokeballXOffset
      @pokeballsprite.y=self.y+@pokeballYOffset
      @pokeballsprite.color=self.color
      @pokeballsprite.changeBitmap(self.selected ? "pokeballsel" : "pokeballdesel")
    end
    if @itemsprite && !@itemsprite.disposed?
      @itemsprite.visible=(!@pokemon.item.nil?)
      if @itemsprite.visible
        @itemsprite.changeBitmap(@pokemon.mail ? "mailbitmap" : "itembitmap")
        @itemsprite.x=self.x+@itemXOffset
        @itemsprite.y=self.y+@itemYOffset
        @itemsprite.color=self.color
      end
    end
    if @refreshBitmap
      @refreshBitmap=false
      self.bitmap.clear if self.bitmap
      if self.selected
        if self.preselected
          if @pokemon.hp<=0 && !@pokemon.isEgg?
            self.bitmap.blt(0,0,@selswapfntbitmap.bitmap,Rect.new(0,0,@selswapfntbitmap.width,@selswapfntbitmap.height))
            self.bitmap.blt(0,0,@deselswapfntbitmap.bitmap,Rect.new(0,0,@deselswapfntbitmap.width,@deselswapfntbitmap.height))
          else
            self.bitmap.blt(0,0,@selswapbitmap.bitmap,Rect.new(0,0,@selswapbitmap.width,@selswapbitmap.height))
            self.bitmap.blt(0,0,@deselswapbitmap.bitmap,Rect.new(0,0,@deselswapbitmap.width,@deselswapbitmap.height))
          end
        elsif @switching
          if @pokemon.hp<=0 && !@pokemon.isEgg?
            self.bitmap.blt(0,0,@selswapfntbitmap.bitmap,Rect.new(0,0,@selswapfntbitmap.width,@selswapfntbitmap.height))
          else
            self.bitmap.blt(0,0,@selswapbitmap.bitmap,Rect.new(0,0,@selswapbitmap.width,@selswapbitmap.height))
          end
        elsif @pokemon.hp<=0 && !@pokemon.isEgg?
          self.bitmap.blt(0,0,@selfntbitmap.bitmap,Rect.new(0,0,@selfntbitmap.width,@selfntbitmap.height))
        else
          self.bitmap.blt(0,0,@selbitmap.bitmap,Rect.new(0,0,@selbitmap.width,@selbitmap.height))
        end
      else
        if self.preselected
          if @pokemon.hp<=0 && !@pokemon.isEgg?
            self.bitmap.blt(0,0,@deselswapfntbitmap.bitmap,Rect.new(0,0,@deselswapfntbitmap.width,@deselswapfntbitmap.height))
          else
            self.bitmap.blt(0,0,@deselswapbitmap.bitmap,Rect.new(0,0,@deselswapbitmap.width,@deselswapbitmap.height))
          end
        elsif @pokemon.hp<=0 && !@pokemon.isEgg?
          self.bitmap.blt(0,0,@deselfntbitmap.bitmap,Rect.new(0,0,@deselfntbitmap.width,@deselfntbitmap.height))
        else
          self.bitmap.blt(0,0,@deselbitmap.bitmap,Rect.new(0,0,@deselbitmap.width,@deselbitmap.height))
        end
      end
      ### MODDED/
      if @pokemon.piece && Input::press?(Input::SHIFT)
        roleidxes = [:KING,:QUEEN,:BISHOP,:KNIGHT,:ROOK,:PAWN]
        self.bitmap.blt(@pieceX,@pieceY,@pieces.bitmap,Rect.new(roleidxes.index(@pokemon.piece)*32,0,32,32))
      end
      ### /MODDED
      base=Color.new(248,248,248)
      shadow=Color.new(40,40,40)
      pbSetSystemFont(self.bitmap)
      pokename=@pokemon.name
      textpos=[[pokename,@pokenameX,@pokenameY,0,base,shadow]]
      if !@pokemon.isEgg?
        if !@text || @text.length==0
          tothp=@pokemon.totalhp
          textpos.push([_ISPRINTF("{1: 3d}/{2: 3d}",@pokemon.hp,tothp),
             @hpX,@hpY,1,base,shadow])
          barbg=(@pokemon.hp<=0) ? @hpbarfnt : @hpbar
          barbg=(self.preselected || (self.selected && @switching)) ? @hpbarswap : barbg
          barbg= ((self.preselected || (self.selected && @switching)) && @pokemon.hp<=0) ? @hpbarswapfnt : barbg
          self.bitmap.blt(@hpbarX,@hpbarY,barbg.bitmap,Rect.new(0,0,@hpbar.width,@hpbar.height))
          hpgauge=@pokemon.totalhp==0 ? 0 : (self.hp*96/@pokemon.totalhp)
          hpgauge=1 if hpgauge==0 && self.hp>0
          hpzone=0
          hpzone=1 if self.hp<=(@pokemon.totalhp/2.0).floor
          hpzone=2 if self.hp<=(@pokemon.totalhp/4.0).floor
          hpcolors=[
             Color.new(24,192,32),Color.new(96,248,96),   # Green
             Color.new(232,168,0),Color.new(248,216,0),   # Orange
             Color.new(248,72,56),Color.new(248,152,152)  # Red
          ]
          # fill with HP color
          self.bitmap.fill_rect(@gaugeX,@gaugeY,hpgauge,2,hpcolors[hpzone*2])
          self.bitmap.fill_rect(@gaugeX,@gaugeY+2,hpgauge,4,hpcolors[hpzone*2+1])
          self.bitmap.fill_rect(@gaugeX,@gaugeY+6,hpgauge,2,hpcolors[hpzone*2])
          if @pokemon.hp==0 || !@pokemon.status.nil?
            status=(@pokemon.hp==0) ? :FAINTED : @pokemon.status
            imagepos=[]
            imagepos.push([sprintf("Graphics/Pictures/Party/status%s",status),@statusX,@statusY,0,0,44,16])
            pbDrawImagePositions(self.bitmap,imagepos)
          end
        end
        if @pokemon.isMale?
          textpos.push([_INTL("♂"),@genderX,@genderY,0,Color.new(0,112,248),Color.new(120,184,232)])
        elsif @pokemon.isFemale?
          textpos.push([_INTL("♀"),@genderX,@genderY,0,Color.new(232,32,16),Color.new(248,168,184)])
        end
      end
      pbDrawTextPositions(self.bitmap,textpos)
      if !@pokemon.isEgg?
        pbSetSmallFont(self.bitmap)
        leveltext=[([_INTL("Lv.{1}",@pokemon.level),@levelX,@levelY,0,base,shadow])]
        pbDrawTextPositions(self.bitmap,leveltext)
      end
      if @text && @text.length>0
        pbSetSystemFont(self.bitmap)
        annotation=[[@text,@annotX,@annotY,0,base,shadow]]
        pbDrawTextPositions(self.bitmap,annotation)
      end
    end
    @refreshing=false
  end
end

class PokemonScreen

  alias :chessdisplay_old_pbPokemonScreen :pbPokemonScreen
  def pbPokemonScreen
    pbChessRoles($Trainer.party,false)
    chessdisplay_old_pbPokemonScreen
  end
  
  alias :chessdisplay_old_pbSwitch :pbSwitch
  def pbSwitch(oldid,newid)
    chessdisplay_old_pbSwitch(oldid,newid)
    pbChessRoles($Trainer.party,false) if oldid != newid
  end
end

class PokemonScreen_Scene

  def pbChoosePokemon(switching=false,allow_party_switch=false,canswitch=0)
    for i in 0...6
      @sprites["pokemon#{i}"].preselected=(switching&&i==@activecmd)
      @sprites["pokemon#{i}"].switching=switching
    end
    oldshift = false
    pbRefresh
    loop do
      Graphics.update
      Input.update
      self.update
      oldsel=@activecmd
      key=-1
      key=Input::DOWN if Input.repeat?(Input::DOWN)
      key=Input::RIGHT if Input.repeat?(Input::RIGHT)
      key=Input::LEFT if Input.repeat?(Input::LEFT)
      key=Input::UP if Input.repeat?(Input::UP)
      if key>=0
        @activecmd=pbChangeSelection(key,@activecmd)
      end
      ### MODDED/
      newshift = Input.press?(Input::SHIFT)
      if oldshift != newshift
        oldshift = newshift
        pbRefresh
      end
      ### /MODDED
      if @activecmd!=oldsel # Changing selection
        pbPlayCursorSE()
        numsprites=(@multiselect) ? 8 : 7
        for i in 0...numsprites
          @sprites["pokemon#{i}"].selected=(i==@activecmd)
        end
      end
      if allow_party_switch && canswitch==0 && Input.trigger?(Input::X)
        return [1,@activecmd]
      elsif allow_party_switch && Input.trigger?(Input::X) && canswitch==1
        return @activecmd
      end
      if Input.trigger?(Input::B)
        return -1
      end
      if Input.trigger?(Input::C)
        pbPlayDecisionSE()
        cancelsprite=(@multiselect) ? 7 : 6
        return (@activecmd==cancelsprite) ? -1 : @activecmd
      end
    end
  end
end
