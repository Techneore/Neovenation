# Toggle Spice Scent Mod
# Adds the use of the Poke Ball as if it were a key item to toggle the Spice Scent encounter rate.

# Using the item sets the Spice Scent encoutner rate to zero. 
# If the Spice Scent encoutner rate is already zero, it will be set to 9000. 
# Use it to toggle between 9000 and 0 whenever you like. 
# A message shows the new value when it is used.
# Can also be registered from a key item.

# Most of this code is from the Rejuv team. Give them a cookie.
# Mod by jmedley

ItemHandlers::UseFromBag.add(:POKEBALL,proc{|item|
  if $game_variables[:EncounterRateModifier].to_f*100 < 100
    $game_variables[:EncounterRateModifier]=9000.to_f/100
  else
    $game_variables[:EncounterRateModifier]=0.to_f/100
  end
  Kernel.pbMessage(_INTL("Spice Scent encounter rate: {1}",($game_variables[:EncounterRateModifier]*100).to_i))
  if defined?($game_map.map_id)
    $PokemonEncounters.setup($game_map.map_id)
  end
  next 1 # Continue
})

ItemHandlers::UseInField.add(:POKEBALL,proc{|item|
  if $game_variables[:EncounterRateModifier].to_f*100 < 100
    $game_variables[:EncounterRateModifier]=9000.to_f/100
  else
    $game_variables[:EncounterRateModifier]=0.to_f/100
  end
  Kernel.pbMessage(_INTL("Spice Scent encounter rate: {1}",($game_variables[:EncounterRateModifier]*100).to_i))
  if defined?($game_map.map_id)
    $PokemonEncounters.setup($game_map.map_id)
  end
  next 1 # Continue
})

class PokemonBagScreen
  def pbStartScreen
    @scene.pbStartScene(@bag)
    item=nil
    loop do
      item=@scene.pbChooseItem
      break if item.nil?
      cmdUse=-1
      cmdRegister=-1
      cmdGive=-1
      cmdToss=-1
      cmdRead=-1
      commands=[]
      # Generate command list
      commands[cmdRead=commands.length]=_INTL("Read") if pbIsMail?(item)
      commands[cmdUse=commands.length]=_INTL("Use") if ItemHandlers.hasOutHandler(item) || (pbIsTM?(item) && $Trainer.party.length>0)
      commands[cmdGive=commands.length]=_INTL("Give") if $Trainer.party.length>0 && !pbIsImportantItem?(item)
      commands[cmdToss=commands.length]=_INTL("Toss") if !pbIsImportantItem?(item) || $DEBUG
      if @bag.registeredItems.include?(item)
        commands[cmdRegister=commands.length]=_INTL("Deselect")
      elsif ItemHandlers.hasKeyItemHandler(item)
        commands[cmdRegister=commands.length]=_INTL("Register")
      end
      commands[commands.length]=_INTL("Cancel")
      # Show commands generated above
      itemname=getItemName(item) # Get item name
      command=@scene.pbShowCommands(_INTL("{1} is selected.",itemname),commands)
      if cmdUse>=0 && command==cmdUse # Use item
        ret=pbUseItem(@bag,item,@scene)
        # 0=Item wasn't used; 1=Item used; 2=Close Bag to use in field
        break if ret==2 # End screen
        @scene.pbRefresh
        next
      elsif cmdRead>=0 && command==cmdRead # Read mail
        pbFadeOutIn(99999){
           pbDisplayMail(PokemonMail.new(item,"",""))
        }
      elsif cmdRegister>=0 && command==cmdRegister # Register key item
        if @bag.pbIsRegistered?(item)
          @bag.pbUnregisterItem(item)
        else
          @bag.pbRegisterItem(item)
        end
        @scene.pbRefresh
      elsif cmdGive>=0 && command==cmdGive # Give item to Pokémon
        if $Trainer.pokemonCount==0
          @scene.pbDisplay(_INTL("There is no Pokémon."))
        elsif pbIsImportantItem?(item)
          @scene.pbDisplay(_INTL("The {1} can't be held.",itemname))
        elsif Rejuv && $game_variables[650] > 0 
          @scene.pbDisplay(_INTL("You are not allowed to change the rental team's items."))
        else
          # Give item to a Pokémon
          pbFadeOutIn(99999){
             sscene=PokemonScreen_Scene.new
             sscreen=PokemonScreen.new(sscene,$Trainer.party)
             sscreen.pbPokemonGiveScreen(item)
             @scene.pbRefresh
          }
        end
      elsif cmdToss>=0 && command==cmdToss # Toss item
        qty=@bag.pbQuantity(item)
        helptext=_INTL("Toss out how many {1}(s)?",itemname)
        qty=@scene.pbChooseNumber(helptext,qty)
        if qty>0
          if pbConfirm(_INTL("Is it OK to throw away {1} {2}(s)?",qty,itemname))
            pbDisplay(_INTL("Threw away {1} {2}(s).",qty,itemname))
            qty.times { @bag.pbDeleteItem(item) }
          end
        end
      end
    end
    @scene.pbEndScene
    return item
  end
end