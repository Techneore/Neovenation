class Battler_Effects
  attr_accessor :effects
  def initialize
    @effects = {}
    #turn count
  end
end